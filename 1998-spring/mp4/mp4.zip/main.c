//  ECE291 MP4 : Everitt 3D
//  -----------------------
//  Prof. John W. Lockwood
//  Unversity of Illinois
//  Dept. of Electrical & Computer Engineering
//  Spring 1998
//  Guest Author: Mike Carter
//  Revision 1.0 Beta 6
//
//  Main.c performs the following functions.
//    * Generation of the floating point lookup tables
//    * Ray casting (i.e., finding intersections with blocks)
//    * Main Loop (invokes your MP4.ASM subroutines)


#include <math.h>
#include "main.h"

// ********** Build_Tables **********

void Build_Tables(void) 
{

  int ang;
  float rad_angle;

  for (ang=ANGLE_0; ang<=ANGLE_360; ang++)
  {
     rad_angle = (3.272e-4) + ang * 2*3.141592654/ANGLE_360;
     tan_table[ang]     = tan(rad_angle);
     inv_tan_table[ang] = 1/tan_table[ang];
     
     // For our use, tangent has the incorrect signs in all quadrants except 1, so
     // the signs of each quadrant are fixed manualle since the tangent is
     // equivalent to the slope of a line and if the tangent is wrong
     // then the ray that is case will be wrong
 
     if (ang>=ANGLE_0 && ang<ANGLE_180)
     {
        y_step[ang]        = fabs(tan_table[ang]     * CELL_Y_SIZE);
     }
     else
        y_step[ang]        = -fabs(tan_table[ang]    * CELL_Y_SIZE);
   
     if (ang>=ANGLE_90 && ang<ANGLE_270)
     {
        x_step[ang]        =-fabs(inv_tan_table[ang] * CELL_X_SIZE);
     }
     else
     {
        x_step[ang]        =fabs(inv_tan_table[ang]  * CELL_X_SIZE);
     }
  
     // create the sin and cosine tables to compute distances

     inv_cos_table[ang] = 1/cos(rad_angle);
     inv_sin_table[ang] = 1/sin(rad_angle);

  }
  // Create view correction table.  There is a cosine wave modulated on top of
  // the view distance as a side effect of casting from a fixed point.
  // to cancel this effect out, we multiple by the inverse of the cosine
  // and the result is the proper scale.  Without this we would see a
  // fishbowl effect, which might be desired in some cases?

  for (ang=-ANGLE_30; ang<=ANGLE_30; ang++)
  {
     rad_angle = (3.272e-4) + ang * 2*3.141592654/ANGLE_360;
     correction_table[ang+ANGLE_30] = 1/cos(rad_angle);
  }
}   


// ********** Ray_Caster **********

void Ray_Caster(long x,long y,long view_angle)
{

int stripnumx, stripnumy, x_hit_type, y_hit_type;

int xray=0,        // tracks the progress of a ray looking for Y interesctions
    yray=0,        // tracks the progress of a ray looking for X interesctions
    next_y_cell,   // used to figure out the quadrant of the ray
    next_x_cell,
    cell_x,        // the current cell that the ray is in
    cell_y,
    x_bound,       // the next vertical and horizontal intersection point
    y_bound,
    x_delta,       // the amount needed to move to get to the next cell
    y_delta,       // position
    ray,           // the current ray being cast 0-320
    casting=2,     // tracks the progress of the X and Y component of the ray     
    top_bot,       // Above or below block
    left_right,    // Left or right of block
    scale; 
      
float xi,           // used to track the x and y intersections
      yi,
      dist_x,       // Distance of strips from player...
      dist_y;
       

// initialization :
// compute starting angle from player.  Field of view is 60 degrees, so
// subtract half of that current view angle

if ( (view_angle-=ANGLE_30) < 0)
   view_angle=ANGLE_360 + view_angle;

// loop through all 320 rays
for (ray=0; ray<320; ray++)
    {
        dist_y = 0;
        dist_x = 0;

    // compute first x intersection
    // need to know which half plane we are casting from relative to Y axis

    if (view_angle >= ANGLE_0 && view_angle < ANGLE_180)
       {
        y_bound = (CELL_Y_SIZE + (y & 0xffc0));
        y_delta = CELL_Y_SIZE;
        xi = inv_tan_table[view_angle] * (y_bound - y) + x;
        next_y_cell = 0;
        top_bot = 0;
       } 
    else
       {
        y_bound = (int)(y & 0xffc0);
        y_delta = -CELL_Y_SIZE;
        xi = inv_tan_table[view_angle] * (y_bound - y) + x;
        next_y_cell = -1;
        top_bot = 63;
       } 

    // compute first y intersection
    // need to know which half plane we are casting from relative to X axis

    if (view_angle < ANGLE_90 || view_angle >= ANGLE_270)
       {
        x_bound = (int)(CELL_X_SIZE + (x & 0xffc0));
        x_delta = CELL_X_SIZE;
        yi = tan_table[view_angle] * (x_bound - x) + y;
        next_x_cell = 0;
        left_right = 63;
       } 
    else
       {
        x_bound = (int)(x & 0xffc0);
        x_delta = -CELL_X_SIZE;
        yi = tan_table[view_angle] * (x_bound - x) + y;
        next_x_cell = -1;
        left_right = 0;
       } 

    casting       = 2;                // two rays to cast simultaneously
    xray=yray     = 0;                // reset intersection flags


    while(casting)
         {

         // continue casting each ray in parallel

         if (xray!=INTERSECTION_FOUND)
            {

               // compute current map position to inspect
               cell_x = ( (x_bound+next_x_cell) >> CELL_X_SIZE_FP);
               cell_y = (int)yi;
               cell_y>>=CELL_Y_SIZE_FP;

               // test if there is a block where the current x ray is intersecting
               if ((x_hit_type = _WorldValue(cell_x, cell_y ))!=0)
               {
                  // Check for a door.      
                  if ( CheckDoor( cell_x,cell_y, 0 ) )
                    if ( CheckDoor( cell_x, (int)(yi+=y_step[view_angle]/2.0) >> CELL_Y_SIZE_FP, 0 ) ) 
                       if ((stripnumx = ((int)yi & 0x003f) ) < 64)
                       {
                          dist_x = (yi - y) * inv_sin_table[view_angle];
                          xray = INTERSECTION_FOUND;
                          casting--;
                       } 
                       else
                       {
                          yi+=y_step[view_angle]/2.0;
                          x_bound+=x_delta;
                       }
                    else      
                    {
                       dist_x = 1e+8;
                       xray = INTERSECTION_FOUND;
                       casting--;
                    }
                  else
                  {
                     // compute distance
                     dist_x  = (yi - y) * inv_sin_table[view_angle];
                     stripnumx = abs(left_right - ((int)yi & 0x003f));
                     xray = INTERSECTION_FOUND;
                     casting--;
                  }  
               } 
               else
               {
                  if (yray == INTERSECTION_FOUND && (yi - y) * inv_sin_table[view_angle] > dist_y)
                  {
                     // There's no point in continuing
                     dist_x = 1e+8;
                     xray = INTERSECTION_FOUND;
                     casting--;
                  }
                  else
                  {
                  // compute next Y intercept
                  yi += y_step[view_angle];
                  x_bound += x_delta;
                  } 
               }
            } 
 
         // Check for a Y intersection
         if (yray!=INTERSECTION_FOUND)
            {      
               // compute current map position to inspect
               cell_x = (int)xi;
               cell_x>>=CELL_X_SIZE_FP;
               cell_y = ( (y_bound + next_y_cell) >> CELL_Y_SIZE_FP);

               // test if there is a block where the current y ray is intersecting
               if ((y_hit_type = _WorldValue( (int) cell_x, (int) cell_y ))!=0 )
               {
                  // Check for a door.      
                  if ( CheckDoor( cell_x, cell_y, 0 ) )
                    if ( CheckDoor( (int)(xi+=x_step[view_angle]/2.0) >> CELL_X_SIZE_FP, cell_y, 0 ) )
                       if ( (stripnumy = ((int)xi & 0x003f)) < 64 )
                       {   
                          dist_y = (xi - x) * inv_cos_table[view_angle];
                          yray = INTERSECTION_FOUND;
                          casting--;
                       }
                       else
                       {
                          xi+=x_step[view_angle]/2.0;
                          y_bound+=y_delta;
                       }
                    else         
                    {                     
                       dist_y = 1e+8;
                       yray = INTERSECTION_FOUND;
                       casting--;
                    }
                  else
                  {                      
                     // compute distance
                     dist_y  = (xi - x) * inv_cos_table[view_angle];
                     stripnumy = abs(top_bot - ((int)xi & 0x003f)); 
                     yray = INTERSECTION_FOUND;
                     casting--;
                  }
               } 
               else
               {
                  if (xray == INTERSECTION_FOUND && (xi - x) * inv_cos_table[view_angle] > dist_x)
                  { 
                     // There's no point in continuing
                     dist_y = 1e+8;
                     yray = INTERSECTION_FOUND;
                     casting--;
                  }
                  else
                  {  
                     // compute next X intercept
                     xi += x_step[view_angle];
                     y_bound += y_delta;
                  } 
               } 
            }
         }  


    // Check to see which intersection was closer and draw it.
      if (dist_x < dist_y)
      {
       // compute actual scale and multiply by view filter so that spherical
       // distortion is cancelled
         scale = (int)(correction_table[ray]*15000/(1e-10 + dist_x));               
         _DrawStrip( scale, (int) (319 - ray), stripnumx, (x_hit_type - 1), BackGrnd);

      }
      else
      {
       // compute actual scale and multiply by view filter so that spherical
       // distortion is cancelled
         scale = (int)(correction_table[ray]*15000/(1e-10 + dist_y));               
         _DrawStrip( scale, (int) (319 - ray), stripnumy, (y_hit_type - 1), BackGrnd);
      }

      // Check to see if angle need to wrap-around
      if (++view_angle>=ANGLE_360)
       view_angle=0; 
   } 
} 

main (int argc, char* argv[])
{
    int StartX, StartY, Strp, LookAngle, i, j=0;
    
    _InstKey();
    ModeGraph();
    Build_Tables();
    
    if (argc == 1)
    {
       // Map #1 (Map2.dat)
       _SetUpGameData(2);    
       while (!ExitFlag)
       {
           Ray_Caster( Player_X, Player_Y, view_angle );
           _CalculateMovement();
           _ProcessMovement();
           DisplayFrameRate(30);
           _ShowScreenBuffer();
       }
       ExitFlag = 0;
       
       // Feel free to add you own maps here...
    }
    else
    
       switch (argv[1][0])
       {
          case '0': //Keyboard Tester
             SetUpKeyTester();
             while (!ExitFlag)
             {
                KeyTester();
                _ShowScreenBuffer();
             }
             break;
       
          case '1': // Test LoadPCX
             TestLoadPCX();
             _ShowScreenBuffer();
             while(!ExitFlag){}
             break;
          
          case '2': // DrawStrip tester
             _SetUpGameData(2);
             while(!ExitFlag)
             {
                for (i=-64; i<64;i++)
                {
                   if (ExitFlag) break;
                   for (LookAngle = 0; LookAngle < ANGLE_180; LookAngle++)
                   {
                      StartX = 160 + 100/inv_cos_table[LookAngle];
                      StartY = 200/inv_sin_table[LookAngle];
                      if ((Strp = (int)((StartX-60)/3.125 + i)) < 64 && Strp > 0)
                         DrawStrip ( StartY, StartX, Strp, j, BackGrnd);  
                   }
                   _ShowScreenBuffer();
                }
                if (!ExitFlag && j++ > 15) j=0;
                for (i=64; i>-64;i--)
                {
                   if (ExitFlag) break;
                   for (LookAngle = 0; LookAngle < ANGLE_180; LookAngle++)
                   {
                      StartX = 160 + 100/inv_cos_table[LookAngle];
                      StartY = 200/inv_sin_table[LookAngle];
                      if ((Strp = (int)((StartX-60)/3.125 + i)) < 64 && Strp > 0)
                         DrawStrip ( StartY, StartX, Strp, j, BackGrnd);  
                   }
                   _ShowScreenBuffer();
                }
                if (!ExitFlag && j++ > 15) j=0;
             }
             ExitFlag = 0;
             for (i=0; i<128; i++)
             { 
                DrawStrip ( 128, 96+i, i/2, j, BackGrnd );
             }
             StripTesterDisp(0);
             _ShowScreenBuffer();
             while(!ExitFlag){};
             ExitFlag = 0;
             for (i=0; i<128; i++)
             { 
                _DrawStrip ( 128, 96+i, i/2, j, BackGrnd );
             }
             StripTesterDisp(1);
             _ShowScreenBuffer();
             while(!ExitFlag){};   
             break;
          
          case '3': // Rotating Logo (Map1.dat)
             _SetUpGameData(1);
             StartX = Player_X;
             StartY = Player_Y;   
             while (!ExitFlag)
             {
                if (view_angle >= ANGLE_360)
                   view_angle -= ANGLE_360;
                LookAngle = view_angle - ANGLE_180;
                if  (LookAngle <= ANGLE_0)
                   LookAngle += ANGLE_360;
                Player_X = StartX + 650/inv_cos_table[view_angle];
                Player_Y = StartY + 650/inv_sin_table[view_angle]; 
                Ray_Caster( Player_X, Player_Y, LookAngle );
                DisplayFrameRate();
                _ShowScreenBuffer();
                view_angle+=ANGLE_1;
             }
             break;
          }
    _DeInstallKey();
    mp4xit();
}
            
               
                  

                  
