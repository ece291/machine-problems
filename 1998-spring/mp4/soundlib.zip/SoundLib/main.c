//  ECE291 MP5 : Everitt 3D : Spear of Assembly
//  --------------------------------------------
//  Prof. John W. Lockwood
//  Unversity of Illinois
//  Dept. of Electrical & Computer Engineering
//  Spring 1998
//  Guest Author: Mike Carter
//  Revision 1.0 Beta 1
//
//  Main.c performs the following functions.
//    * Generation of the floating point lookup tables
//    * Ray casting (i.e., finding intersections with blocks)
//    * Main Loop (invokes your MP5.ASM subroutines)


#include <math.h>
#include "main.h"


// ********** Build_Tables **********

void Build_Tables(void) 
{

  int ang;
  float rad_angle;

  for (ang=ANGLE_0; ang<=ANGLE_360; ang++)
  {
     rad_angle = (3.272e-4) + ang * 2*3.141592654/ANGLE_360;
     tan_table[ang]     = tan(rad_angle);
     inv_tan_table[ang] = 1/tan_table[ang];
     
     // For our use, tangent has the incorrect signs in all quadrants except 1, so
     // the signs of each quadrant are fixed manualle since the tangent is
     // equivalent to the slope of a line and if the tangent is wrong
     // then the ray that is case will be wrong
 
     if (ang>=ANGLE_0 && ang<ANGLE_180)
     {
        y_step[ang]        = fabs(tan_table[ang]     * CELL_Y_SIZE);
     }
     else
        y_step[ang]        = -fabs(tan_table[ang]    * CELL_Y_SIZE);
   
     if (ang>=ANGLE_90 && ang<ANGLE_270)
     {
        x_step[ang]        =-fabs(inv_tan_table[ang] * CELL_X_SIZE);
     }
     else
     {
        x_step[ang]        =fabs(inv_tan_table[ang]  * CELL_X_SIZE);
     }
  
     // create the sin and cosine tables to compute distances

     inv_cos_table[ang] = 1/cos(rad_angle);
     inv_sin_table[ang] = 1/sin(rad_angle);

  }
  // Create view correction table.  There is a cosine wave modulated on top of
  // the view distance as a side effect of casting from a fixed point.
  // to cancel this effect out, we multiple by the inverse of the cosine
  // and the result is the proper scale.  Without this we would see a
  // fishbowl effect, which might be desired in some cases?

  for (ang=-ANGLE_30; ang<=ANGLE_30; ang++)
  {
     rad_angle = (3.272e-4) + ang * 2*3.141592654/ANGLE_360;
     correction_table[ang+ANGLE_30] = 1/cos(rad_angle);
  }
}


int DoorPosition(int BlockX, int BlockY)
{
   int i;
   
   for(i=0;i<10;i++)
   {
      if (DoorList[i].BlockX == BlockX && DoorList[i].BlockY == BlockY)
      {
         if (DoorList[i].DoorStatus == 1)
            return 64;
         else
            return (int)DoorList[i].DoorPos;
      }
   }
   return 0;   
}

int FindDoor(int BlockX, int BlockY)
{
   int i;
   
   for(i=0;i<10;i++)
   {
      if (DoorList[i].BlockX == BlockX && DoorList[i].BlockY == BlockY)
         return i;
   }
   return 0;
}

void MoveDoors()
{
   int PBlockX, PBlockY, BlockX, BlockY, InX, InY;
   int i, NextDoor=0, BlockNum;
   
   InX = Player_X & 0x003f;
   InY = Player_Y & 0x003f;
   
   PBlockX = Player_X >> 6;
   PBlockY = Player_Y >> 6;
   
   // Move all doors and find the lowest empty door position.
   for (i=0;i<10;i++)
   {
      if (DoorList[i].BlockX == 0 && DoorList[i].BlockY == 0 && NextDoor == 0)
         NextDoor = i;
      else
      {
         DoorList[i].DoorPos += DoorList[i].DoorSpeed;
         if (DoorList[i].DoorStatus == 0 && DoorList[i].DoorPos > 64)
         {
            CheckDoor(DoorList[i].BlockX, DoorList[i].BlockY, 4);
            DoorList[i].DoorStatus = 1;
            DoorList[i].DoorPos = 0;
         }
         else if (DoorList[i].DoorStatus == 1 && DoorList[i].DoorPos > 128)
         {
            if (PBlockX != DoorList[i].BlockX || PBlockY != DoorList[i].BlockY)
            {
               PlaySound(DOORCLOSING);
               CheckDoor(DoorList[i].BlockX, DoorList[i].BlockY, 5);
               DoorList[i].DoorStatus = 2;
               DoorList[i].DoorPos = 64;
               DoorList[i].DoorSpeed = -DoorList[i].DoorSpeed;
            }
         }
         else if (DoorList[i].DoorStatus == 2 && DoorList[i].DoorPos < 0)
         {
            DoorList[i].BlockX = 0;
            DoorList[i].BlockY = 0;
            DoorList[i].DoorPos = 0;
            DoorList[i].DoorSpeed = 0;
            DoorList[i].DoorStatus = 0;
         }
      }
   }
            
   // Open or close a door   
   if (Open)
   {
      if (view_angle < ANGLE_45 || view_angle > ANGLE_315 && CheckDoor(PBlockX + 1, PBlockY, 0) && InX > 32)
      {
         BlockX = PBlockX + 1;
         BlockY = PBlockY;
      }                 
      else if (view_angle > ANGLE_45 && view_angle < ANGLE_135 && CheckDoor(PBlockX, PBlockY + 1, 0) && InY > 32)
      {
         BlockX = PBlockX;
         BlockY = PBlockY + 1;
      }     
      else if (view_angle > ANGLE_135 && view_angle < ANGLE_225 && CheckDoor(PBlockX - 1, PBlockY, 0) && InX < 32)
      {
         BlockX = PBlockX - 1;
         BlockY = PBlockY;
      }        
      else if (view_angle > ANGLE_225 && view_angle < ANGLE_315 && CheckDoor(PBlockX, PBlockY - 1, 0) && InY < 32)
      {
         BlockX = PBlockX;
         BlockY = PBlockY - 1;
      }
      else
         return;
   
      Open=0;
      if (DoorPosition(BlockX, BlockY) == 0)   // Door is closed and should be opened
      {   
         PlaySound(DOOROPENING);
         DoorList[NextDoor].BlockX = BlockX;
         DoorList[NextDoor].BlockY = BlockY;
         DoorList[NextDoor].DoorSpeed = (float)(64.0/(FrameRate*2));
      }
      else 
      {
         BlockNum = FindDoor(BlockX, BlockY);
         if (DoorList[BlockNum].DoorStatus == 0)         // Door is opening...Close it.
         {
            PlaySound(DOORCLOSING);
            DoorList[BlockNum].DoorStatus = 2;
            DoorList[BlockNum].DoorSpeed = -DoorList[BlockNum].DoorSpeed;
         }
         else if (DoorList[BlockNum].DoorStatus == 1)    // Door is open...Close it
         {  
            PlaySound(DOORCLOSING);
            CheckDoor(BlockX, BlockY, 5); 
            DoorList[BlockNum].DoorPos = 64;
            DoorList[BlockNum].DoorSpeed = -DoorList[BlockNum].DoorSpeed;
            DoorList[BlockNum].DoorStatus = 2;
         }
         else                                     // Door is closing...Open it.
         {
            PlaySound(DOOROPENING);    
            DoorList[BlockNum].DoorStatus = 0;
            DoorList[BlockNum].DoorSpeed = -DoorList[BlockNum].DoorSpeed;
         }
      }                    
   }                         
   return;
}    


float WallPosition(int BlockX, int BlockY)
{
   int i;
   
   if (WallList.BlockX == BlockX && WallList.BlockY == BlockY)
      return WallList.WallPos;
   else
      return 0;   
}


void MoveWall()
{
   int PBlockX, PBlockY, BlockX, BlockY, InX, InY;
   
   InX = Player_X & 0x003f;
   InY = Player_Y & 0x003f;
   
   PBlockX = Player_X >> 6;
   PBlockY = Player_Y >> 6;
   
   // Move the wall if it needs it.


   if (WallList.WallStatus == 1)
      WallList.WallPos += WallList.WallSpeed;
         
   if (WallList.WallPos > 1)
   {      
      CheckDoor(WallList.BlockX, WallList.BlockY, 6);
      WallList.BlockX += WallList.WallXDir;
      WallList.BlockY += WallList.WallYDir;
      WallList.WallPos = 0.0; 
      CheckDoor(WallList.BlockX, WallList.BlockY, 7);
      if (WorldValue(WallList.BlockX + WallList.WallXDir, WallList.BlockY + WallList.WallYDir) != 0)
      {

         WallList.BlockX = 0;
         WallList.BlockY = 0;
         WallList.WallStatus = 0; 
         WallList.WallSpeed = 0.0;
      } 
      else
         PlaySound(WALLCONTINU);
         
   }
         
            
   // Push a wall  
   if (Open)
   {
      Open = 0;
      if (view_angle < ANGLE_45 || view_angle > ANGLE_315 && CheckDoor(PBlockX + 1, PBlockY, 3) && InX > 32)
      {
         WallList.WallXDir = 1;
         WallList.WallYDir = 0;
      }                 
      else if (view_angle > ANGLE_45 && view_angle < ANGLE_135 && CheckDoor(PBlockX, PBlockY + 1, 3) && InY > 32)
      {
         WallList.WallXDir = 0;
         WallList.WallYDir = 1;
      }     
      else if (view_angle > ANGLE_135 && view_angle < ANGLE_225 && CheckDoor(PBlockX - 1, PBlockY, 3) && InX < 32)
      {
         WallList.WallXDir = -1;
         WallList.WallYDir = 0;
      }        
      else if (view_angle > ANGLE_225 && view_angle < ANGLE_315 && CheckDoor(PBlockX, PBlockY - 1, 3) && InY < 32)
      {
         WallList.WallXDir = 0;
         WallList.WallYDir = -1;
      }
      else
         return;
   
      if (WallList.WallStatus != 1 && CheckDoor(PBlockX + 2*WallList.WallXDir, PBlockY + 2*WallList.WallYDir, 1))
      {
         PlaySound(WALLSLIDING);
         WallList.BlockX = PBlockX + WallList.WallXDir;
         WallList.BlockY = PBlockY + WallList.WallYDir;
         WallList.WallSpeed = (float)(1.0/(FrameRate*2));
         WallList.WallStatus = 1;
      }                    
   }                         
   return;
} 

int RenderPlayer()
{ 

   double RelAngle, dist;
   int i, j, DelX, DelY, height;
   int ScreenAngle, NumVisible=0, Lowest, LowNum;
   int Temp, Shot=0;
   Strip DepthList[NUMPLAYERS];
   int Order[NUMPLAYERS];
   
   for (i=0; i<NUMPLAYERS; i++)
   {
      if ((Temp = Players[i].Status) == 1 )
      {
         // First get the Relative angle in radians.
         DelX = Players[i].X - Player_X;    // The X distance between you and the other player.
         DelY = Players[i].Y - Player_Y;    // The Y distance between you and the other player.        
         
         // Convert to a table value relative to view_angle
         if ( (RelAngle = atan2( (double) DelY, (double) DelX )*(ANGLE_360/PI4) + ANGLE_360) > ANGLE_360 )
            RelAngle -= ANGLE_360;  
            
         
         if ( view_angle < ANGLE_60 && (int)RelAngle > ANGLE_270)
            ScreenAngle =  view_angle + ANGLE_360 - (int) RelAngle + 160;
         else if ( view_angle > ANGLE_270 && (int)RelAngle < ANGLE_60 )
            ScreenAngle = view_angle - ANGLE_360 - (int) RelAngle + 160;
         else
            ScreenAngle = view_angle - (int) RelAngle + 160;      
      
         // The distance straight from you to the other player.
         dist = sqrt( pow( (double)DelX, 2) + pow( (double)DelY, 2) );

         if ( ScreenAngle < 0 ) 
            height = (int)(correction_table[0]*15000/(1e-10 + dist));
         else if ( ScreenAngle > 320 )
            height = (int)(correction_table[320]*15000/(1e-10 + dist));
         else
            height = (int)(correction_table[ScreenAngle]*15000/(1e-10 + dist));
      
         // Is the player in view?
         if (ScreenAngle < (320+height/2) && ScreenAngle > (0-height/2))
         {
            NumVisible++;
            DepthList[i].X         = ScreenAngle;
            DepthList[i].Height    = height;                 
            DepthList[i].Texture   = Players[i].Texture;
            if ( RelAngle - ANGLE_180 < 0 )
               DepthList[i].view_angle = (int)RelAngle + ANGLE_180;
            else
               DepthList[i].view_angle = (int)RelAngle - ANGLE_180;
            DepthList[i].i         = 0;
         }
         else
            DepthList[i].i = 1;
         
      }
      else 
         DepthList[i].i = 1;
   } 
   // Depth sort the players
   for ( i=0; i<NumVisible; i++ )
   {
      Lowest = INFINITY;
      for (j=0; j<NUMPLAYERS; j++)
      {          
         if ( DepthList[j].i == 0 && Lowest > DepthList[j].Height )
         {
            Lowest = DepthList[j].Height;
            LowNum = j;
         }
      }
      if (_DrawPlayer( DepthList[LowNum].Height, DepthList[LowNum].X, DepthList[LowNum].Texture) != 0)
      {
         Shot = LowNum + 1;
         if (SelChase == 1)
         {
            _asm{cli}            
            CompMovement(DepthList[LowNum].view_angle);
            Players[LowNum].X += (int)CompDelta_X;
            Players[LowNum].Y += (int)CompDelta_Y;
            CompDelta_X = 0;
            CompDelta_Y = 0;
            _asm{sti}
         }
      } 
      if (AllChase == 1)
      {
         _asm{cli}            
         CompMovement(DepthList[LowNum].view_angle);
         Players[LowNum].X += (int)CompDelta_X;
         Players[LowNum].Y += (int)CompDelta_Y;
         CompDelta_X = 0;
         CompDelta_Y = 0;
         _asm{sti}
      }
      DepthList[LowNum].i = 1;
   }
   return Shot;   
}

// ********** Ray_Caster **********

void Ray_Caster(long x,long y,long view_angle)
{

int stripnumx, stripnumy, x_hit_type, y_hit_type;

int xray=0,        // tracks the progress of a ray looking for Y interesctions
    yray=0,        // tracks the progress of a ray looking for X interesctions
    next_y_cell,   // used to figure out the quadrant of the ray
    next_x_cell,
    cell_x,        // the current cell that the ray is in
    cell_y,
    x_bound,       // the next vertical and horizontal intersection point
    y_bound,
    x_delta,       // the amount needed to move to get to the next cell
    y_delta,       // position
    ray,           // the current ray being cast 0-320
    casting=2,     // tracks the progress of the X and Y component of the ray     
    top_bot,       // Above or below block
    left_right,    // Left or right of block
    scale,
    i, temp1, temp2; 
      
float xi,           // used to track the x and y intersections
      yi,
      dist_x,       // Distance of strips from player...
      dist_y;   

// initialization :
// compute starting angle from player.  Field of view is 60 degrees, so
// subtract half of that current view angle

if ( (view_angle-=ANGLE_30) < 0)
   view_angle=ANGLE_360 + view_angle;

// loop through all 320 rays
for (ray=0; ray<320; ray++)
    {   
        TransparentList[(int)(319 - ray)].Height1 = 0;
        TransparentList[(int)(319 - ray)].Height2 = 0;
        dist_y = 0;                             
        dist_x = 0;

    // compute first x intersection
    // need to know which half plane we are casting from relative to Y axis

    if (view_angle >= ANGLE_0 && view_angle < ANGLE_180)
       {
        y_bound = (CELL_Y_SIZE + (y & 0xffc0));
        y_delta = CELL_Y_SIZE;
        xi = inv_tan_table[view_angle] * (y_bound - y) + x;
        next_y_cell = 0;
        top_bot = 0;
       } 
    else
       {
        y_bound = (int)(y & 0xffc0);
        y_delta = -CELL_Y_SIZE;
        xi = inv_tan_table[view_angle] * (y_bound - y) + x;
        next_y_cell = -1;
        top_bot = 63;
       } 

    // compute first y intersection
    // need to know which half plane we are casting from relative to X axis

    if (view_angle < ANGLE_90 || view_angle >= ANGLE_270)
       {
        x_bound = (int)(CELL_X_SIZE + (x & 0xffc0));
        x_delta = CELL_X_SIZE;
        yi = tan_table[view_angle] * (x_bound - x) + y;
        next_x_cell = 0;
        left_right = 63;
       } 
    else
       {
        x_bound = (int)(x & 0xffc0);
        x_delta = -CELL_X_SIZE;
        yi = tan_table[view_angle] * (x_bound - x) + y;
        next_x_cell = -1;
        left_right = 0;
       } 

    casting       = 2;                // two rays to cast simultaneously
    xray=yray     = 0;                // reset intersection flags


    while(casting)
         {

         // continue casting each ray in parallel

         if (xray!=INTERSECTION_FOUND)
            {

               // compute current map position to inspect
               cell_x = ( (x_bound+next_x_cell) >> CELL_X_SIZE_FP);
               cell_y = (int)yi;
               cell_y>>=CELL_Y_SIZE_FP;
               
               // test if there is a block where the current x ray is intersecting
               if ((x_hit_type = WorldValue(cell_x, cell_y ))!=0)
               {
                  // Check for a door.      
                  if ( CheckDoor( cell_x,cell_y, 0 ) )
                    if ( CheckDoor( cell_x, (int)(yi+=y_step[view_angle]/2.0) >> CELL_Y_SIZE_FP, 0 ) ) 
                       if ((stripnumx = (((int)yi & 0x003f) + DoorPosition(cell_x, cell_y)) ) < 64)
                       {

                          if (CheckDoor( cell_x, (int)yi >> CELL_Y_SIZE_FP, 2) )
                          {
                             // Transparent block
                             
                             if (TransparentList[(int)(319 - ray)].Height1 == 0)
                             {
                                TransparentList[(int)(319 - ray)].Height1 = (int)(correction_table[ray]*15000/(1e-10 + (yi - y)*inv_sin_table[view_angle]));
                                TransparentList[(int)(319 - ray)].Texture1 = WorldValue(cell_x, (int)yi >> CELL_Y_SIZE_FP) - 1;
                                TransparentList[(int)(319 - ray)].Strip1 = stripnumx;
                             }
                             else if (TransparentList[(int)(319 - ray)].Height2 < (int)(correction_table[ray]*15000/(1e-10 + (yi - y)*inv_sin_table[view_angle])))
                             {
                                TransparentList[(int)(319 - ray)].Height2 = (int)(correction_table[ray]*15000/(1e-10 + (yi - y)*inv_sin_table[view_angle]));
                                TransparentList[(int)(319 - ray)].Texture2 = WorldValue(cell_x, (int)yi >> CELL_Y_SIZE_FP) - 1;
                                TransparentList[(int)(319 - ray)].Strip2 = stripnumx;
                             }
                             yi+=y_step[view_angle]/2.0;
                             x_bound+=x_delta;
                          }
                          else
                          {
                             dist_x = (yi - y) * inv_sin_table[view_angle];
                             xray = INTERSECTION_FOUND;
                             casting--;
                          }
                       } 
                       else
                       {
                          yi+=y_step[view_angle]/2.0;
                          x_bound+=x_delta;
                       }
                    else      
                    {
                       dist_x = 1e+8;
                       xray = INTERSECTION_FOUND;
                       casting--;
                    }
                  else
                  if ( CheckDoor( cell_x, cell_y, 3) )
                     if ( CheckDoor( cell_x, (int)(yi+=y_step[view_angle]*WallPosition(cell_x, cell_y)) >> CELL_Y_SIZE_FP, 3) )
                     {
                        dist_x = (yi - y) * inv_sin_table[view_angle];
                        stripnumx = abs(left_right - ((int)yi & 0x003f));
                        xray = INTERSECTION_FOUND;
                        casting--;
                     }
                     else
                     {
                        yi+=y_step[view_angle]*(1-WallPosition(cell_x, cell_y));
                        x_bound+=x_delta;
                     }
                  else
                  {
                     // compute distance
                     if (CheckDoor( cell_x, cell_y, 2) )
                     {
                        // Transparent block     
                        if (TransparentList[(int)(319 - ray)].Height1 < (int)(correction_table[ray]*15000/(1e-10 + (yi - y)*inv_sin_table[view_angle])))
                        {
                           TransparentList[(int)(319 - ray)].Height1 = (int)(correction_table[ray]*15000/(1e-10 + (yi - y)*inv_sin_table[view_angle]));
                           TransparentList[(int)(319 - ray)].Texture1 = WorldValue(cell_x, (int)yi >> CELL_Y_SIZE_FP) - 1;
                           TransparentList[(int)(319 - ray)].Strip1 = abs(left_right - ((int)yi & 0x003f));
                         }
                         yi+=y_step[view_angle];
                         x_bound+=x_delta;
                      }
                      else
                      {
                         dist_x = (yi - y) * inv_sin_table[view_angle];
                         stripnumx = abs(left_right - ((int)yi & 0x003f));
                         xray = INTERSECTION_FOUND;
                         casting--;
                     }
                  }  
               } 
               else
               {
                  if (yray == INTERSECTION_FOUND && (yi - y) * inv_sin_table[view_angle] > dist_y)
                  {
                     // There's no point in continuing
                     dist_x = 1e+8;
                     xray = INTERSECTION_FOUND;
                     casting--;
                  }
                  else
                  {
                  // compute next Y intercept
                  yi += y_step[view_angle];
                  x_bound += x_delta;
                  } 
               }
            } 
 
         // Check for a Y intersection
         if (yray!=INTERSECTION_FOUND)
            {      
               // compute current map position to inspect
               cell_x = (int)xi;
               cell_x>>=CELL_X_SIZE_FP;
               cell_y = ( (y_bound + next_y_cell) >> CELL_Y_SIZE_FP);

               // test if there is a block where the current y ray is intersecting
               if ((y_hit_type = WorldValue( (int) cell_x, (int) cell_y ))!=0 )
               {
                  // Check for a door.      
                  if ( CheckDoor( cell_x, cell_y, 0 ) )
                    if ( CheckDoor( (int)(xi+=x_step[view_angle]/2.0) >> CELL_X_SIZE_FP, cell_y, 0 ) )
                       if ( (stripnumy = (((int)xi & 0x003f) + DoorPosition(cell_x, cell_y)))  < 64 )
                       {   
                          if (CheckDoor( (int)xi >> CELL_X_SIZE_FP, cell_y, 2) )
                          {
                             // Transparent block
                             if (TransparentList[(int)(319 - ray)].Height1 < (int)(correction_table[ray]*15000/(1e-10 + (xi - x)*inv_cos_table[view_angle])))
                             {
                                TransparentList[(int)(319 - ray)].Height1 = (int)(correction_table[ray]*15000/(1e-10 + (xi - x)*inv_cos_table[view_angle]));  
                                TransparentList[(int)(319 - ray)].Texture1 = WorldValue((int)xi >> CELL_X_SIZE_FP, cell_y) - 1;
                                TransparentList[(int)(319 - ray)].Strip1 = stripnumy;
                             }
                             else if (TransparentList[(int)(319 - ray)].Height2 < (int)(correction_table[ray]*15000/(1e-10 + (xi - x)*inv_cos_table[view_angle])))
                             {
                                TransparentList[(int)(319 - ray)].Height2 = (int)(correction_table[ray]*15000/(1e-10 + (xi - x)*inv_cos_table[view_angle]));  
                                TransparentList[(int)(319 - ray)].Texture2 = WorldValue((int)xi >> CELL_X_SIZE_FP, cell_y) - 1;
                                TransparentList[(int)(319 - ray)].Strip2 = stripnumy;
                             }
                             xi+=x_step[view_angle]/2.0;
                             y_bound+=y_delta;
                          }
                          else
                          {
                             dist_y = (xi - x) * inv_cos_table[view_angle];
                             yray = INTERSECTION_FOUND;
                             casting--;
                          }
                       }
                       else
                       {
                          xi+=x_step[view_angle]/2.0;
                          y_bound+=y_delta;
                       }
                    else         
                    {                     
                       dist_y = 1e+8;
                       yray = INTERSECTION_FOUND;
                       casting--;
                    }
                  else 
                  if ( CheckDoor( cell_x, cell_y, 3) )
                     if ( CheckDoor( (int)(xi+=x_step[view_angle]*WallPosition(cell_x, cell_y)) >> CELL_X_SIZE_FP, cell_y, 3) )
                     {
                        dist_y = (xi - x) * inv_cos_table[view_angle];
                        stripnumy = abs(top_bot - ((int)xi & 0x003f));
                        yray = INTERSECTION_FOUND;
                        casting--;
                     }
                     else
                     {
                        xi+=x_step[view_angle]*(1-WallPosition(cell_x, cell_y));
                        y_bound+=y_delta;
                     }
                  else
                  {                      
                     // compute distance
                     if (CheckDoor( cell_x, cell_y, 2) )
                     {
                        // Transparent block
                        if (TransparentList[(int)(319 - ray)].Height1 < (int)(correction_table[ray]*15000/(1e-10 + (xi - x)*inv_cos_table[view_angle])))
                        {
                           TransparentList[(int)(319 - ray)].Height1 = (int)(correction_table[ray]*15000/(1e-10 + (xi - x)*inv_cos_table[view_angle]));  
                           TransparentList[(int)(319 - ray)].Texture1 = WorldValue((int)xi >> CELL_X_SIZE_FP, cell_y) - 1;
                           TransparentList[(int)(319 - ray)].Strip1 = abs(top_bot - ((int)xi & 0x003f));
                        }                 
                        xi+=x_step[view_angle];
                        y_bound+=y_delta;
                     }
                     else
                     {
                        dist_y = (xi - x) * inv_cos_table[view_angle];
                        stripnumy = abs(top_bot - ((int)xi & 0x003f)); 
                        yray = INTERSECTION_FOUND;
                        casting--;
                     }
                  }
               } 
               else
               {
                  if (xray == INTERSECTION_FOUND && (xi - x) * inv_cos_table[view_angle] > dist_x)
                  { 
                     // There's no point in continuing
                     dist_y = 1e+8;
                     yray = INTERSECTION_FOUND;
                     casting--;
                  }
                  else
                  {  
                     // compute next X intercept
                     xi += x_step[view_angle];
                     y_bound += y_delta;
                  } 
               } 
            }
         }  


    // Check to see which intersection was closer and draw it.
      if (dist_x < dist_y)
      {
       // compute actual scale and multiply by view filter so that spherical
       // distortion is cancelled
         scale = (int)(correction_table[ray]*15000/(1e-10 + dist_x));
         ScaleList[(int) (319 - ray)] = scale;               
         _DrawStrip( scale, (int) (319 - ray), stripnumx, (x_hit_type - 1), BackGrnd);

      }
      else
      {
       // compute actual scale and multiply by view filter so that spherical
       // distortion is cancelled
         scale = (int)(correction_table[ray]*15000/(1e-10 + dist_y));
         ScaleList[(int) (319 - ray)] = scale;               
         _DrawStrip( scale, (int) (319 - ray), stripnumy, (y_hit_type - 1), BackGrnd);
      }

      // Check to see if angle need to wrap-around
      if (++view_angle>=ANGLE_360)
       view_angle=0; 
   } 
} 

main ()
{
    int Temp, FadeMe=0;
    InstKey();

    ModeGraph();
    Build_Tables();
    GetSBSettings();
    SoundInit();
    // PlaySound(GUNSHOT);
    
    ShowIntroScreens();       
    // Map #1 (Map2.dat)
    SetUpGameData(2);
    GetPlayerTexture();
    ShowScreenBuffer();
    InstTimer();    
    while (!ExitFlag)
    { 
       //CalculateMovement(view_angle); 
       //ProcessMovement();
       Ray_Caster( Player_X, Player_Y, view_angle );
       Temp = RenderPlayer();
       FinishTransparentStrips();
       if (_ProcessShot())
       {
          if (Temp == 0)
             PlaySound(MISSEDSHOT);
          else
             PlaySound(GUNSHOT);
          Shooting = Temp;
       }
       MoveDoors();
       MoveWall();            
       _ProcessNetworkData();
       _ProcessChat();
       DisplayFrameRate();
       ShowScreenBuffer();
       if (FadeMe == 0)
       {
          Fade(0);
          FadeMe = 1;
       }
    }
    PlaySound(DOH);
    Fade(-1);
    SoundEnd();
    DeInstallKey();
    DeInstallTimer();
    ModeText();

}
            
               
                  

                  
