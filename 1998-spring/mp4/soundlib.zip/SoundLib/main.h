
// Header file for 3D Project  3DProj.H

// Constants
#define CELL_X_SIZE        64
#define CELL_Y_SIZE        64
#define CELL_X_SIZE_FP   6   // log base 2 of 64 (used for quick division)
#define CELL_Y_SIZE_FP   6
#define INTERSECTION_FOUND  1
#define PI1                 1.57079632679
#define PI2                 3.14159265359
#define PI3                 4.18879020479
#define PI4                 6.28318538718
#define RAY_INCREMENT       0.003272492

// Table angle values
#define ANGLE_0     0
#define ANGLE_1     5
#define ANGLE_2     10
#define ANGLE_4     20
#define ANGLE_5     25
#define ANGLE_6     30
#define ANGLE_15    80
#define ANGLE_30    160
#define ANGLE_45    240
#define ANGLE_60    320
#define ANGLE_90    480
#define ANGLE_135   720
#define ANGLE_180   960
#define ANGLE_225   1200
#define ANGLE_270   1440
#define ANGLE_315   1680
#define ANGLE_360   1920
#define NUMPLAYERS  24
#define INFINITY    15000

#define LONGTIMECONS    210     //22050 hz - use higher sound quality
#define SHORTTIMECONS   165     //11025 hz - use lower sound quality

// Sound effect constants
#define DOORCLOSING     "sound/door.raw", 18462, SHORTTIMECONS 
#define DOOROPENING     "sound/door.raw", 18462, SHORTTIMECONS
#define WALLSLIDING    "sound/stone.raw", 60271, SHORTTIMECONS
#define WALLCONTINU   "sound/stone2.raw", 49381, SHORTTIMECONS
#define GUNSHOT          "sound/gun.raw", 16126, SHORTTIMECONS
#define MISSEDSHOT  "sound/ricochet.raw", 13179, SHORTTIMECONS
#define MENUTRANS   "sound/changmen.raw",   849, SHORTTIMECONS
#define MENUSEL      "sound/menusel.raw",  7123, SHORTTIMECONS
#define DOH              "sound/doh.raw",  4880, SHORTTIMECONS

// Sound hardware constants
#define DMA_BUF_SIZE    8192
#define DMA8_FF_REG      0xC
#define DMA8_MASK_REG    0xA
#define DMA8_MODE_REG    0xB
#define DMA16_FF_REG    0xD8
#define DMA16_MASK_REG  0xD4
#define DMA16_MODE_REG  0xD6

#define DMA0_ADDR        0
#define DMA0_COUNT       1
#define DMA0_PAGE     0x87
#define DMA1_ADDR        2
#define DMA1_COUNT       3
#define DMA1_PAGE     0x83
#define DMA3_ADDR        6
#define DMA3_COUNT       7
#define DMA3_PAGE     0x82
#define DMA5_ADDR     0xC4
#define DMA5_COUNT    0xC6
#define DMA5_PAGE     0x8B
#define DMA6_ADDR     0xC8
#define DMA6_COUNT    0xCA
#define DMA6_PAGE     0x89
#define DMA7_ADDR     0xCC
#define DMA7_COUNT    0xCE
#define DMA7_PAGE     0x8A

#define DSP_BLOCK_SIZE            0x0048
#define DSP_DATA_AVAIL               0xE
#define DSP_HALT_SINGLE_CYCLE_DMA 0x00D0
#define DSP_READ_PORT                0xA
#define DSP_READY                   0xAA
#define DSP_RESET                    0x6
#define DSP_TIME_CONSTANT         0x0040
#define DSP_WRITE_PORT               0xC
#define DSP_VERSION                    0xE1

#define AUTO_INIT                   1
#define FAIL                        0
#define FALSE                       0
#define MASTER_VOLUME            0x22
#define MIC_VOLUME               0x0A
#define MIXER_ADDR                0x4
#define MIXER_DATA                0x5
#define MONO                        0
#define PIC_END_OF_INT           0x20
#define PIC_MASK                 0x21
#define PIC_MODE                 0x20
#define SUCCESS                     1
#define SINGLE_CYCLE                0
#define STEREO                      1
#define TRUE                        1
#define VOICE_VOLUME             0x04

// Procedures either written in MP4 or given.
extern void far ModeText();
extern void far ModeGraph();
extern void far InstKey(void);
extern void far DeInstallKey();
extern void far InstTimer();
extern void far DeInstallTimer();
extern void far ShowScreenBuffer();
extern void far SetUpGameData(int);
extern void far CalculateMovement(int);
extern void far CompMovement(int);
extern void far FinishTransparentStrips();
extern void far ProcessMovement();
extern int  far WorldValue(int, int);
extern void far DisplayFrameRate();
extern void far GetPlayerTexture();
extern void far ShowIntroScreens();
extern int  far CheckDoor(int, int, int);
extern void far Fade(int);

// Procedures that need to be written (or modified) for MP5
extern int  far _DrawStrip(int, int, int, int, int);
extern int  far _DrawPlayer(int, int, int);
extern void far _ProcessChat();
extern void far _ProcessNetworkData();
extern int  far _ProcessShot();

// Sound procedures
extern void far GetSBSettings();
extern void far SoundInit();
extern void far PlaySound(char far*, unsigned int, unsigned int);
extern void far SoundEnd();

// The other(network) players are placed into this structure.
typedef struct 
{
  unsigned char Status;
  unsigned int X;
  unsigned int Y;
  unsigned char Shooting;
  unsigned int Texture;
  unsigned int view_angle;
} NetPlayer;

// Data used to sort the players as they are rendered
typedef struct
{
  unsigned int  X;         // Screen position of the player.
  unsigned int  Height;    // Scaled height of the player
  unsigned int  Texture;   // Texture of the player.
  unsigned int  view_angle;// They're view angle if they were looking straight at you.
  unsigned char i;         // Sorted?
} Strip;

typedef struct
{
  unsigned int Height1;
  unsigned int Texture1;
  unsigned int Strip1;
  unsigned int Height2;
  unsigned int Texture2;
  unsigned int Strip2;
} Trans;  

// Holds the data for a moving door.
typedef struct
{
  unsigned int  BlockX;
  unsigned int  BlockY;
  float         DoorPos;
  float         DoorSpeed;
  unsigned int  DoorStatus;
} Door;

// Holds the data for a moving wall
typedef struct
{
   unsigned int  BlockX;
   unsigned int  BlockY;
   float         WallPos;
   float         WallSpeed;
   unsigned int  WallStatus;
   int           WallXDir;
   int           WallYDir;
} Wall;

// Global variables defined in MP4.asm
extern unsigned char far ExitFlag;
extern unsigned char far Open;
extern unsigned int  far Player_X;
extern unsigned int  far Player_Y;
extern unsigned int  far view_angle;
extern unsigned int  far BackGrnd;
extern unsigned int  far FrameRate;
extern unsigned char far SelChase;
extern unsigned char far AllChase;
extern unsigned int  far Shooting;
extern NetPlayer     far Players[];
extern unsigned int  far ScaleList[];
extern Trans         far TransparentList[];
extern float         far CompDelta_X;
extern float         far CompDelta_Y;
extern float         far inv_cos_table[];
extern float         far inv_sin_table[];

extern unsigned int  far BaseAddr;
extern unsigned char far IRQ;
extern unsigned char far DMA_Low;
extern unsigned char far DMA_High;

                              
float tan_table[1921];        // tangent tables used to compute initial
float inv_tan_table[1921];    // intersections with ray
float y_step[1921];           // x and y steps, used to find intersections
float x_step[1921];           // after initial one is found
float correction_table[1921]; // used to cancel out fishbowl effect

Door DoorList[10];
Wall WallList;
