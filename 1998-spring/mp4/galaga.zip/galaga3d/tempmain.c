#include <stdio.h>
#include <malloc.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <math.h>
#include "graphics.h"
#include "mysystem.h"
#include "utils.h"
#include "ship.h"


/*==============================
	constants       
  ==============================*/

const char cursorFile[] = "data\\cursor.pcx";
const char menuFile[] = "data\\menu.pcx";
const char fontFile[] = "data\\font.pcx";
const char backgroundFile[] = "data\\image2.pcx";
const char statBarFile[] = "data\\statbar.pcx";

const int levelCount = 1;
const int Menu_music = 0;
const int Game_music = 1;

const RGBColor BlackColor = {0,0,0};
const mySegment ScreenSeg = 0xA000;

mySegment ScratchSeg, ScratchSegB;
char *theFont, *statBarStorage, *statusBar;
char *theMusic;
int currentpos=0;

/*==============================
	support routines
  ==============================*/

void FlyingLetters();
void Explosion();	   
int MainMenu();			   
void HiLight (int pos);
void DeHiLight (int pos);

char *LoadMIDI(char *filename) {
	char *XMIdata;  		// buffer
	FILE *XMIfile;
	int FileLength;
	if ((XMIfile = fopen(filename, "rb")) == NULL)
		FatalError("could not open file");
	else {
		fseek(XMIfile, 0, SEEK_END);
		FileLength = ftell(XMIfile);
		fseek(XMIfile, 0, SEEK_SET);
   		if ((XMIdata = (char*)malloc(FileLength))==NULL)
			FatalError("could not allocate midi buffer");
		if (!fread(XMIdata, FileLength, 1, XMIfile))
       		FatalError("could not read file");
 	}	
	fclose(XMIfile);
	RegisterXMidi(XMIdata, FileLength);
	return XMIdata;
}

void InitMidi() {
	theMusic = LoadMIDI("data\\descent.XMI");
	SetRelativeVolume(100);
	}

void InitGame() {
	Palette nullPalette;
	ScratchSeg = GetScratchSeg();
	ScratchSegB = GetScratchSegB();
	if (!LoadPCX(fontFile, &theFont, &nullPalette))
		FatalError(fontFile);
	if (!LoadPCX(statBarFile, &statusBar, &nullPalette))
		FatalError("could not load status bar");
	statBarStorage = (char *)((long)ScratchSegB<<16);
	theDrawBuffer = GetShipDrawBuffer();
	SetMode13();
	InitMidi();

//	InitSound();
	}

ShutDownMidi() {
	MidiStop();
	free(theMusic);
	}

void GameShutdown() {
	SetModeText();
	free(theFont);
	free(statusBar);
	free(statBarStorage);
	free(theMusic);
	ShutDownMidi();
//	ShutDownSound();
	}

void Intro() {
	Palette nullPalette, thePalette;
	char *theBackground = NULL, *theMenu = NULL, *theTitle2 = NULL;
	col colorIndex;
	fixed factor;
	int tempInt;

	if (!LoadPCX(menuFile, &theMenu, &nullPalette))
		FatalError("could not load menu pcx");
	if (!LoadPCX("data\\3d.pcx", &theTitle2, &nullPalette))
		FatalError("could not load 3d.pcx");
	if (!LoadPCX("data\\image2.pcx", &theBackground, &thePalette))
		FatalError("could not load menu background");


	for (colorIndex=255; colorIndex>0; colorIndex--)
		nullPalette.theColors[colorIndex] = BlackColor;
	FadeIn(&thePalette, 5000);

	SlideIn(theBackground, theMenu, 9900);

	if (!CheckKey()) {
		FlyingLetters();
		SetDrawDest(ScreenSeg);
		for(tempInt=0; tempInt<40 & !CheckKey(); tempInt++) {
			AddDrawBitmap(theTitle2, 165, 100);
			MyDelay(15000);
			}
		
		for(tempInt=0; tempInt<100 && !CheckKey(); tempInt++)
			MyDelay(10000);

		if (!CheckKey())
			Explosion();
		
		if (!CheckKey()) {
			GetBitmap(theMenu, 80, 50, 160, 100, ScreenSeg);
			SlideOut(theBackground, theMenu, 5000);
			}
		SetDrawDest(ScreenSeg);
		if (!CheckKey()) {
			FillScreen(0);
			}
		}
	FadeOut(5000);
	FillScreen(0);
	free(theBackground); free(theMenu);

	}

void FlyingLetters() {
	Palette nullPalette;
	char *letterG = NULL, *letterA = NULL, *letterL = NULL;
	char *shapes[6];
	int posX[6] = {85, 109, 137, 156, 182, 206};
	int	factor[6] = {0, -50, -100, -150, -200, -230};
	int temp;
 
	if (!LoadPCX("f:\\galaga\\data\\g.pcx", &letterG, &nullPalette))
		FatalError("Could not load G");
	if (!LoadPCX("f:\\galaga\\data\\a.pcx", &letterA, &nullPalette))
		FatalError("Could not load A");
	if (!LoadPCX("f:\\galaga\\data\\l.pcx", &letterL, &nullPalette))
		FatalError("Could not load L");

	shapes[0] = letterG; shapes[1] = letterA; shapes[2] = letterL;
	shapes[3] = letterA; shapes[4] = letterG; shapes[5] = letterA;

	ScreenToScreen(ScratchSegB, ScreenSeg);
	SetDrawDest(ScratchSeg);
	while (factor[5] < 256 & !CheckKey()) {
		ScreenToScreen(ScratchSeg, ScratchSegB);
		for(temp=0; temp<6; temp++) {
			factor[temp]+= 1;
			if (factor[temp] > 256)
				factor[temp] = 256;
			if (factor[temp]>0)
				TSDrawBitmap(shapes[temp], posX[temp], 82, factor[temp], factor[temp]);
			}
		ScreenToScreen(ScreenSeg, ScratchSeg);
		MyDelay(2500);
		}
	
	free(letterG); free(letterA); free(letterL);
	}

void Explosion() {
	char *burst = NULL;
	Palette nullPalette;
	int tempInt, currDot;
	int	vx[500], vy[500], x[500], y[500];

	LoadPCX("f:\\galaga\\data\\burst.pcx", &burst, &nullPalette);

	ScreenToScreen(ScratchSegB, ScreenSeg);
	SetDrawDest(ScratchSeg);

	for(currDot=0; currDot<500 & !CheckKey(); currDot++) {
		x[currDot] = (rand() % 580) + 340;
		y[currDot] = (rand() % 252) + 328;
		vx[currDot] = (rand() % 100) - 50;
		if (!vx[currDot])
			vx[currDot]++;
		vy[currDot] = -(rand() % 140);
		if (!vy[currDot])
			vy[currDot]++;
		}

	for(tempInt=0; tempInt<450 & !CheckKey(); tempInt++) {
		ScreenToScreen(ScratchSeg, ScratchSegB);
		for(currDot=0; currDot<500; currDot++) {
			x[currDot] += (vx[currDot]>>5);
			y[currDot] += (vy[currDot]>>5);
			vy[currDot]++;

			if ((y[currDot] > 0) && (y[currDot]<784) && (x[currDot]>0) && (x[currDot]<1264)) {
				TDrawBitmap(burst, (x[currDot]>>2), (y[currDot]>>2));
				}
			}
		ScreenToScreen(ScreenSeg, ScratchSeg);
		MyDelay(5000);
		}
	free(burst);

	}

void HiLight (int pos) {
	switch (pos) {
		case 0 : SetTextXY(16, 40); DrawText(theFont, "\001\001PLAY THE GAME\001\001", 255,23);break;
		case 1 : SetTextXY(16, 50); DrawText(theFont, "\001\001CREDITS\001\001\001\001\001\001\001\001", 255, 23);break;
		case 2 : SetTextXY(16, 60); DrawText(theFont, "\001\001QUIT\001\001\001\001\001\001\001\001\001\001\001", 255, 23);break;
	}
	return;
}

void DeHiLight (int pos) {
	switch (pos) {
		case 0 : SetTextXY(16, 40); DrawText(theFont, "\001\001PLAY THE GAME\001\001", 255,0);break;
		case 1 : SetTextXY(16, 50); DrawText(theFont, "\001\001CREDITS\001\001\001\001\001\001\001\001", 255, 0);break;
		case 2 : SetTextXY(16, 60); DrawText(theFont, "\001\001QUIT\001\001\001\001\001\001\001\001\001\001\001", 255, 0);break;
	}
	return;
}

	

int MainMenu() {
	char *theBackground = NULL, *theMenu = NULL, *theFont = NULL, *theTitle = NULL;
	char tempChar;
	Palette nullPalette, thePalette;
	col colorIndex;
	int returnVal=0;

	LoadPCX(backgroundFile, &theBackground, &thePalette);
	LoadPCX(menuFile, &theMenu, &nullPalette);
	LoadPCX(fontFile, &theFont, &nullPalette);
	LoadPCX("data\\gsmall.pcx", &theTitle, &nullPalette);

	for(colorIndex=255; colorIndex>0; colorIndex--)
		nullPalette.theColors[colorIndex] = BlackColor;

	SetDrawDest(ScratchSeg);
	DrawBitmap(theMenu, 0, 0);
	TDrawBitmap(theTitle, 26, 3);	
	SetTextXY(16, 40); DrawText(theFont, "\001\001PLAY THE GAME\001\001", 255,23);
	SetTextXY(16, 50); DrawText(theFont, "\001\001CREDITS\001\001\001\001\001\001\001\001", 255, 0);
	SetTextXY(16, 60); DrawText(theFont, "\001\001QUIT\001\001\001\001\001\001\001\001\001\001\001", 255, 0);
	GetBitmap(theMenu, 0, 0, 160, 100, ScratchSeg);

	if (!CheckKey()) {
		SetPalette(&thePalette);
		SlideIn(theBackground, theMenu, 5000);
		}
	if (CheckKey()) {
//		FadeOut(5000);
		SetDrawDest(ScreenSeg);
		BufferToScreen(theBackground);
		DrawBitmap(theMenu, 80, 50); 
//		FadeIn(&thePalette, 5000);
		SetPalette(&thePalette);
		}

	while (CheckKey())
		getch();

	
	
	do {
		
		switch (tempChar = toupper(getch())) {
			case 0xe0
			case 'P' : 	returnVal=1; break;
			case 27: 	returnVal=0; break;
			default: 	returnVal = -1; break;
			}
		} while (returnVal == -1);

	FadeOut(5000);
	free(theBackground); free(theMenu); free(theFont);
	return returnVal;
	}

int PlayLevel(FILE *levelFile, Palette *thePalettePtr, char *theFloor, char *theCeiling, char *theShips) {
	char *statusBar = NULL;
	Palette nullPalette;
	int maxTime;
	Ship *tempShip;

	if (!LoadPCX(statBarFile, &statusBar, &nullPalette))
		FatalError(statBarFile);

	fscanf(levelFile, "%u\n", &maxTime);
	ClearShipBuffer();

    SetDrawDest(ScratchSeg);
	InstallTimeInt();
	MouseCtrl(0, 0, 305, 165);
	ShowMouse();

	FadeIn(thePalettePtr, 25000);
	
	if ((tempShip = FReadShip(levelFile))==NULL)
		FatalError("Could not read ship information");

	AddShipToDrawBuffer(tempShip);

	while (!CheckKey() && !MouseButton() && (GetTime() < maxTime)) {
		DrawStatusBar();
		UpdateShips();
		}

	DestroyShip(0);

	FadeOut(25000);
	DeInstallTime();

	return 0;
	}

void PlayGame() {
	FILE *levelFile;
	char filename[255], floorFilename[255], ceilingFilename[255], shipFilename[255], errorMsg[255];
	char tempStr[255];
	char *tempStrPtr;
	int levelNum=1, diedFlag=0;
	char *mouseCsr = GetMouseBuffer(), *theFloor = NULL, *theCeiling = NULL;
	char *theShips = GetShipBuffer();

	Palette thePalette, nullPalette;
	
	if (!LoadPCX(cursorFile, &mouseCsr, &nullPalette)) {
		FatalError(strcat("Could not load ", cursorFile));
		}

	//clear the keyboard buffer
	while (CheckKey())
		getch();
	
	for (levelNum=1; (levelNum <= levelCount) & !diedFlag; levelNum++) {
		itoa(levelNum, tempStr, 10);
		strcpy(filename, "data\\level");
		strcat(filename, tempStr); strcat(filename, ".lvl");
		if ((levelFile = fopen(filename, "r"))==NULL)
			FatalError("Could not open file");

		fscanf(levelFile, "%s\n", floorFilename);
		fscanf(levelFile, "%s\n", ceilingFilename);
		fscanf(levelFile, "%s\n", shipFilename);
		fscanf(levelFile, "%s\n", shipFilename);

		theFloor = NULL; theCeiling = NULL;
		if (!LoadPCX(floorFilename, &theFloor, &nullPalette))
			FatalError("");
		if (!LoadPCX(ceilingFilename, &theCeiling, &nullPalette))
			FatalError("");
		if (!LoadPCX(shipFilename, &theShips, &thePalette))
			FatalError("");
		SetFloorCeiling(theFloor, theCeiling);
		

		switch (PlayLevel(levelFile, &thePalette, theFloor, theCeiling, theShips)) {
			case 0: diedFlag=1; break;
			case 1: FatalError("Passed level?!??"); break;
			default: break;
			}

		//dont free mouseCsr... it's from asm
		free(theFloor); free(theCeiling);
		fclose(levelFile);

		}		
	}


void main() {
	int quitFlag=0;

	InitGame();
	PlaySequence(Menu_music);

	Intro();

	do {
		switch (MainMenu()) {
			case 0:	quitFlag = (1==1); break;
			case 1: PlayGame(); break;
			default: break;
			}
		} while (!quitFlag);
	FadeOut(5000);
	GameShutdown();
	}
