#ifndef __GRAPHICS__
#define __GRAPHICS__

#include "utils.h"

//graphics routines for Galaga3D

//types for graphics.c

typedef struct PCXHeader_t {
    char    manufacturer;
    char  version;
    char  encoding;
    char  bitsPerPixel;
    int     xMin, yMin, xMax, yMax;
    int     horzRes, vertRes;
    char  palette[48];
    char  reserved;
    char  colorPlaneCount;
    int     bytesPerPlane;
    int     paletteType;
    char  filler[58];
    } PCXHeader, *PCXHeaderPtr;

typedef unsigned char col;

typedef struct RGBColor_t {
    col r,g,b;
    } RGBColor, *RGBColorPtr;

typedef struct Palette_t {
    RGBColor theColors[256];
    } Palette, *PalettePtr;


//graphasm.asm routines
extern void SetMode13();
extern void SetModeText();
extern void FillScreen(col attrib);
extern void DrawBitmap(char *theBitmap, int x, int y);
extern void GetBitmap(char *theBitmap, int x, int y, int width, int height, mySegment sourceSeg);
extern void TDrawBitmap(char *theBitmap, int x, int y);
extern void AddDrawBitmap(char *theBitmap, int x, int y);
extern void SetPalette(Palette *thePalette);
extern void GetPalette(Palette *thePalette);
extern void SetShield(char shield);
extern char GetShield();
extern void BufferToScreen(char *theBuffer);
extern void ScreenToScreen(mySegment destSeg, mySegment srcSeg);
extern void WaitSync();
extern void SetDrawDest(mySegment theSegment);
extern void SplitScreen(int scanLine);
extern void FullScreen();
extern void SetStartAddress(int startOffset);
extern char *GetShipBuffer();
extern void Splash();
//extern ShipDrawBuffer *GetShipDrawBuffer();

extern mySegment GetScratchSeg();
extern mySegment GetScratchSegB();
extern void ClearShipBuffer();

//tsdraw.inc
extern void TSDrawBitmap(char *theBitmap, int x, int y , fixed xfactor, fixed yfactor);
// called by assembly
extern void TSDrawXYZ(fixed x, fixed y , fixed z, fixed xyfactor, char picture);

//fontdraw.inc
extern void	SetTextXY(int X, int Y);
extern void DrawText(const char *theBitmap, const char *FontString, col fntcolor, col bkcolor);

//floor.inc
extern void DrawFloor(int yStart, int yEnd, fixed altitude, fixed eyeDist, char *theBitmap, fixed yOffset);
extern void InitFloor();

//headers for C graphics routines
int LoadPCX(const char *filename, char **theBitmap, Palette *tempPalette);
void FadeIn(Palette *thePalette, unsigned long theDelay);
void FadeOut(unsigned long theDelay);
void SlideIn(char *theBackground, char *theMenu, long theDelay);
void SlideOut(char *theBackground, char *theMenu, long theDelay);
void DrawStatusBar();
void FillRect(int Xmin, int Ymin, int Xmax, int Ymax, char Color);

//source code
#endif

