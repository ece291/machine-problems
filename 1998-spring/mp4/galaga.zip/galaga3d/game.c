//game.c

#include <stdio.h>
#include <malloc.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <math.h>
#include <process.h>
#include "graphics.h"		//interface to graphics routines
#include "mysystem.h"		//mouse, interrupt, MIDI, sound routine interface
#include "utils.h"			//number conversion, error, key buffer routines
#include "ship.h"			//interface to enemy management/control routines

/*==============================
	constants       
  ==============================*/

char songFile[] = "data\\game.xmi";
const char cursorFile[] = "data\\cursor.pcx";
const char menuFile[] = "data\\menu.pcx";
const char fontFile[] = "data\\font.pcx";
const char backgroundFile[] = "data\\image2.pcx";
const char statBarFile[] = "data\\statbar.pcx";

const int levelCount = 1;	//number of levels to play
const int Menu_music = 0;	//sequence numbers used by MIDPAK
const int Game_music = 1;

const RGBColor BlackColor = {0,0,0};
const mySegment ScreenSeg = 0xA000;

/*==============================
	globals
  ==============================*/

mySegment ScratchSeg, ScratchSegB;				// ptrs to scratch segs from asm
char *theFont, *statBarStorage, *statusBar;		// global bitmap storgage
char *theMusic;									// where music is stored

int score=0, shield=45;
extern float zmax;		// from graphics.c

/*----------------------------------------------------
-	Shoot()
-	when mouse is clicked, determines whether an enemy ship is hit
	and takes appropriate action
  ----------------------------------------------------*/
void Shoot() {
	int index, foundFlag=0, tempInt;
	fixed coords = MousePos();		//get mouse pos from asm
	float factor;

 //extract mouse coords x, y
	fixed clickY = (coords & 0xFFFF0000) >> 8;
	fixed clickX = (coords & 0x0000FFFF) << 8;

 // search shipDrawBuffer to find any suitable ships
	index=31;
	while (index>=0 && !foundFlag) {
		if (theDrawBuffer->data[index].valid) {
			factor = (zmax - (float)theDrawBuffer->data[index].z)/zmax;
		 //is the current ship under the mouse cursor?

			if ((clickX > theDrawBuffer->data[index].x) && (clickX < theDrawBuffer->data[index].x + Float2Fixed(32.0*factor))) {
			if ((clickY > theDrawBuffer->data[index].y) && (clickY < theDrawBuffer->data[index].y + Float2Fixed(32.0*factor)))
			 	//if yes, note that we found a match
				foundFlag = (1==1);

				//calculate enemy's new hit points
				if ((--(theDrawBuffer->data[index].theShip->hits)) < 0) {
					score += theDrawBuffer->data[index].theShip->points;
					DrawStatusBar();
					//program him to self destruct if hits are < 0
					theDrawBuffer->data[index].theShip->program = 9;
					}
				}
			}
		index--;
		}
	}


/*----------------------------------------------------
-	PlayLevel
-	Plays one level of the game
  ----------------------------------------------------*/
int PlayLevel(FILE *levelFile, Palette *thePalettePtr, char *theFloor, char *theCeiling, char *theShips) {
	char *statusBar = NULL;
	Palette nullPalette;
	int maxTime, temp;
	Ship *pendingShip;

	//load the status bar picture
	if (!LoadPCX(statBarFile, &statusBar, &nullPalette))
		FatalError(statBarFile);

	fscanf(levelFile, "%u\n", &maxTime);	//read how long the level plays for
	ClearShipBuffer();						//erase all ships in the draw buffer

	SetDrawDest(ScratchSeg);				//we're draw to the scratch segment
	InstallTimeInt();						/*start timer ISR (floor, mouse, enemies)
											  timer ISR also copies from scratch seg to
											  main screen*/
	MouseCtrl(0, 0, 305, 165);				//set mouse bounds
	ShowMouse();							//show the mouse cursor

	DrawStatusBar();						//show status bar
	FadeIn(thePalettePtr, 25000);
	
	//loop until we reach max time or are out of ship data in the level file or someone
	//presses a key
	while ((GetTime() < maxTime) && (!feof(levelFile)) && (!CheckKey())) {
		//read the next ship from the config file
		if ((pendingShip = FReadShip(levelFile))==NULL)
			FatalError("Could not read ship information");

		//loop until that should should be inserted in the level
		while ((GetTime() < (pendingShip->creationTime)) && (!CheckKey())) {
			//move all ships
			UpdateShips();

			if (MouseButton() & 0x0001)	Shoot();
			if (MouseButton() & 0x0002) {Splash(); Shoot();}
			MyDelay(20000);
			}
		//when the ship creation time is reached, insert the pending ship
		AddShipToDrawBuffer(pendingShip);
		}

	//loops just until time runs out... if we get here, there are no more ships in the
	//level file
	while ((GetTime() < maxTime) && (!CheckKey())) {
		UpdateShips();
		if (MouseButton() & 0x0001)	Shoot();
		if (MouseButton() & 0x0002) {Splash();	Shoot();}
		MyDelay(20000);
		}

	//destroy any ships that are left when level ends

	while (theDrawBuffer->data[0].valid)
		DestroyShip(0);

	FadeOut(25000);
	DeInstallTime();		// uninstall timer ISR

	return 0;
	}


/*----------------------------------------------------
-	PlayGame()
-	Plays all levels by calling PlayLevel() (above)
  ----------------------------------------------------*/
void PlayGame() {
	//vars
	FILE *levelFile;
	char filename[255], floorFilename[255], ceilingFilename[255], shipFilename[255], errorMsg[255];
	char tempStr[255];
	char *tempStrPtr;
	int levelNum=1, diedFlag=0;
	char *mouseCsr = GetMouseBuffer(), *theFloor = NULL, *theCeiling = NULL;
	char *theShips = GetShipBuffer();
	Palette thePalette, nullPalette;
	
	//load mouse cursor into mouse cursor buffer (at end of ScratchSeg)
	if (!LoadPCX(cursorFile, &mouseCsr, &nullPalette)) {
		FatalError(strcat("Could not load ", cursorFile));
		}

	//clear the keyboard buffer
	while (CheckKey())
		getch();
	
	//loop through each level while we haven't died
	for (levelNum=1; (levelNum <= levelCount) & !diedFlag; levelNum++) {
		itoa(levelNum, tempStr, 10);
		strcpy(filename, "data\\level");
		strcat(filename, tempStr); strcat(filename, ".lvl");
		if ((levelFile = fopen(filename, "r"))==NULL)
			FatalError("Could not open file");

		//read graphics specs from level file
		fscanf(levelFile, "%s\n", floorFilename);
		fscanf(levelFile, "%s\n", ceilingFilename);
		fscanf(levelFile, "%s\n", shipFilename);
		fscanf(levelFile, "%s\n", shipFilename);

		theFloor = NULL; theCeiling = NULL;					//have to do this for LoadPCX
		if (!LoadPCX(floorFilename, &theFloor, &nullPalette))
			FatalError("");
		if (!LoadPCX(ceilingFilename, &theCeiling, &nullPalette))
			FatalError("");
		if (!LoadPCX(shipFilename, &theShips, &thePalette))
			FatalError("");
		SetFloorCeiling(theFloor, theCeiling);		//install floor+ceiling bitmaps
		
		
		switch (PlayLevel(levelFile, &thePalette, theFloor, theCeiling, theShips)) {
			case 0: diedFlag=1; break;
			case 1: diedFlag=0; break;
			default: break;
			}

		//dont free mouseCsr or ShipBuffer... it's in ScratchSeg
		free(theFloor); free(theCeiling);
		fclose(levelFile);
		}		
	}

/*----------------------------------------------------
-	InitGame
-	Perfroms game initialization
  ----------------------------------------------------*/
void InitGame() {
	Palette nullPalette;
	ScratchSeg = GetScratchSeg();				//set global c ptrs to scratch video
	ScratchSegB = GetScratchSegB();

	if (!LoadPCX(fontFile, &theFont, &nullPalette))			//load font
		FatalError(fontFile);
	if (!LoadPCX(statBarFile, &statusBar, &nullPalette))	//load status bar
		FatalError("could not load status bar");
	statBarStorage = (char *)((long)ScratchSegB<<16);
	theDrawBuffer = GetShipDrawBuffer();

	InitMidi();
	SetMode13(); 
	}

/*----------------------------------------------------
-	GameShutdown
-	Performs final cleanup
  ----------------------------------------------------*/
void GameShutdown() {
	SetModeText();
	free(theFont);
	free(statusBar);
	free(statBarStorage);
	free(theMusic);
	MIDIStop();
	}

main() {
	ShipDrawData testData;
	char *songBuffer=NULL;

	InitGame();

	Plot(10,100,105);
	getch();

	songBuffer = LoadMIDI(songFile);
	PlaySequence(0);

	PlayGame();
	GameShutdown();
	execl("main.exe", "main.exe", "-skip", NULL);
	FatalError("execl failed!");
	}