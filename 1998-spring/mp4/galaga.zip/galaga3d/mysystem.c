#include <malloc.h>
#include <stdio.h>
#include "mysystem.h"

/*----------------------------------------------------
  ----------------------------------------------------*/
void InitMidi() {
//    SetRelativeVolume(255);
	}

/*----------------------------------------------------

  ----------------------------------------------------*/
char *LoadMIDI(char *filename) {
	char *XMIdata;  		// buffer
	FILE *XMIfile;
	int FileLength;
	if ((XMIfile = fopen(filename, "rb")) == NULL)
		FatalError("could not open file");
	else {
		fseek(XMIfile, 0, SEEK_END);
		FileLength = ftell(XMIfile);
		fseek(XMIfile, 0, SEEK_SET);
   		if ((XMIdata = (char*)malloc(FileLength))==NULL)
			FatalError("could not allocate midi buffer");
		if (!fread(XMIdata, FileLength, 1, XMIfile))
       		FatalError("could not read file");
 	}	
	fclose(XMIfile);

	switch(RegisterXMidi(XMIdata, FileLength)) {
		case 0: FatalError(filename); break;
		case 1: free(XMIdata); XMIdata==(void *)-1; break;
		default: break;
		}

	return XMIdata;
}

/*----------------------------------------------------
  ----------------------------------------------------*/
void LoadSound(char filename[], SoundStruc *tempSound) {
	FILE *soundFile;
	long fileLen;

	if ((soundFile = fopen(filename, "rb"))==NULL)
		FatalError(filename);
	fseek(soundFile, 0, SEEK_END);
	fileLen = ftell(soundFile);
	fseek(soundFile, 0, SEEK_SET);

	if ((tempSound->sound) == NULL)
		if ((tempSound->sound = malloc(fileLen))==NULL)
			FatalError("could not allocate sound");
	fread(tempSound->sound, fileLen, 1, soundFile);
	tempSound->sndlen = fileLen;
	}

