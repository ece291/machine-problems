Galaga 3d
=========
University of Illinois
ECE291, Spring '97

Niels Gabel, Minn Thein, Rachana Gupta, and Jon Rachwalski

E-mail: gabel@uiuc.edu
http: //www.students.uiuc.edu/~gabel

Summary:

	In this folder are the executable and data files for Galaga 3D, a game we created in three weeks 
(100 hrs of work) as a final project for an assembly language class.  All the graphics routines are written in 
assembly. The 3D techniques were "invented" by us with almost no knowledge or experience with 3d 
graphics.

The floor/ceiling drawing routine is not optimized at all. (We realized during the last 3 days of class that 
this part of the software could about 50 times faster with lookup tables, but we ran out of time.) Be sure to 
run this software on a really fast computer. We used Pentium Pro 200MHz machines, a Pentium II should 
also work.

Because of the limited time, the game was never completed.

Contents:
4. SETUP.BAT
Run this first to set up the sound drivers

6. GALAGA.BAT
Run this to play Galaga 3D.

1. DMKIT (directory)
MIDPAK and DIGPAK sound drivers. See the README.PRN file for more information.

2. DATA (directory)
data files for the game

3. CLOSE.EXE
This utility which will close all files accidentally left open in DOS by a crashed program.

5. GAME.EXE
This is a version of the main game routine in which the enemies can be shot down. This was not 
implemented in the standard executable.

6. MAIN.EXE
This is the standard version of the game.

7. README.TXT
This is the file you are reading.

(c)1997 Niels Gabel
