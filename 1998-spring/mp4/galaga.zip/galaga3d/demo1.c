#include <stdio.h>
#include <malloc.h>
#include "graphics.h"
#include "utils.h"
#include "system.h"
#include "math.h"

const segment ScreenSeg = 0xA000;
const RGBColor nullColor = {0,0,0};

void main() {
    char *theBackground, *theTitle, *theFont, *theClouds, *theGround, *thePlanet;
    Palette thePalette, nullPalette;
	fixed factor, altitude=40*256;
    col temp;
	int tempInt;
	void *tempSeg = (void *)((long)GetScratchSeg()<<16);
	float yMap, tempFloat;
	fixed x, y;
	fixed sinTable[256];
	col currDeg;

    if (!LoadPCX("data\\image10.pcx", &theBackground, &thePalette))
        exit(-1);
    if (!LoadPCX("data\\image11.pcx", &theTitle, &nullPalette))
        exit(-1);
	if (!LoadPCX("data\\circuit.pcx", &theGround, &nullPalette))
		exit(-1);
	if (!LoadPCX("data\\flfcloud.pcx", &theClouds, &nullPalette))
		exit(-1);
	if (!LoadPCX("data\\font.pcx", &theFont, &nullPalette))
		exit(-1);
	if (!LoadPCX("data\\earthmo2.pcx", &thePlanet, &nullPalette))
		exit(-1);
 
 	SetMode13();

    for (temp=255; temp>0; temp--)
        nullPalette.theColors[temp] = nullColor;
    
    SetPalette(&nullPalette);
    SetDrawDest(ScreenSeg);
	BufferToScreen(theBackground);

    FadeIn(&thePalette, 2000);
	factor=0;


	for(altitude = 1; altitude < 4096; altitude +=2) {
		SetDrawDest(GetScratchSeg());
		FillScreen(0);
		DrawFloor(118, 200, 2048, (fixed)512, theGround, (fixed)altitude);
		DrawFloor(0, 84, -2048, (fixed)512, theClouds, (fixed)altitude);
		DrawBitmap(thePlanet, 200, 85);

		tempFloat = *((int *)theTitle);
		x = 160 - *((int *)theTitle) * 128.0 / altitude;
		y = 100 - *((int *)theTitle+1) * 128.0 / altitude;
		TSDrawBitmap(theTitle, (fixed)x, (fixed)y, altitude, altitude);
		SetDrawDest(ScreenSeg);
		ScreenToScreen(tempSeg);
		MyDelay(100000);
		}
	SetDrawDest(GetScratchSeg());
	FillScreen(0);

	for(temp=0; temp<50; temp++)
	for(altitude = 1; altitude < 128; altitude += 2) {
		currDeg = currDeg++;
		SetDrawDest(GetScratchSeg());
		FillScreen(0);
		DrawFloor(118, 200, 2048, 512, theGround, altitude);
		DrawFloor(0, 84, -2048, 512, theClouds, altitude);
		DrawBitmap(thePlanet, 200, 85);
		SetDrawDest(ScreenSeg);
		ScreenToScreen(tempSeg);
		MyDelay(1000);
		}

	getch();

/*
	for(tempFloat=20.0; tempFloat > 0.0001; tempFloat-= 0.1) {
		SetDrawDest(GetScratchSeg());
		BufferToScreen(theBackground);
		TSDrawBitmap(theTitle, 0, 0, Float2Fixed(1.0/tempFloat), Float2Fixed(1.0/tempFloat));
		SetDrawDest(ScreenSeg);
		ScreenToScreen(tempSeg);
		//MyDelay(2500);
		}
	getch();
*/

    FadeOut(&thePalette, 2000);
    SetModeText();

    free(theBackground);
    free(theTitle);
	free(theFont);
	free(theClouds);
	free(theGround);
	free(thePlanet);
    }