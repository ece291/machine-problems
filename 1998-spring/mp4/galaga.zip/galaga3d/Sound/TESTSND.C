#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
#include"fmsound.h"
#include"mixsound.h"
#include"dspsound.h"

void main(void)
{
   int x;

   dsp_settings(SB_ADDR,SB_IRQ,SB_DMA);
   dsp_reset();


   mixer_port(MIXER_ADDR);
   mixer_reset();
   mixer_output(OUT_STEREO,OUT_FILTER);
   mixer_volume(MIX_MASTER,15,15);
   mixer_volume(MIX_FM,12,12);

   fm_port(FM_RIGHT);
   fm_reset();
   fm_envelope(1,1,4,2);
   fm_envelope(1,2,7,0);
   fm_pedal(1,1,10,10);
   fm_modify(1,3,FM_LINK);
   fm_play(1,0xA41);
   fm_volume(1,1,45,0);
   fm_volume(1,2,37,0);


   fm_port(FM_LEFT);
   fm_reset();
   fm_envelope(4,1,2,5);
   fm_envelope(4,2,3,3);
   fm_modify(4,3,FM_LINK);
   fm_harm(4,1,4+FM_VIBRATO+FM_AM);
   fm_volume(4,1,60,0);
   fm_play(4,0x777);

   getch();
   fm_port(FM_RIGHT);
   fm_stopall();
   fm_port(FM_LEFT);
   fm_stopall();
}