//graphics.c for Galaga3D

#include <malloc.h>
#include <stdio.h>
#include <stdlib.h>
#include "graphics.h"
#include "utils.h"

#ifndef FALSE
#define FALSE (1==0)
#endif

#ifndef TRUE
#define TRUE (1==1)
#endif

extern segment ScreenSeg, ScratchSeg, ScratchSegB;

int LoadPCX(const char *filename, char **theBitmap, Palette *tempPalette) {
    PCXHeader theHeader;
    FILE *f = FALSE;

    char *tempBitmap;

    unsigned int index=0, mySize, count;
    unsigned char data;
    
    if ((f = fopen(filename, "rb"))==NULL)
        FatalError("could not open picture in LoadPCX");
    else {
        if (!fread(&theHeader, 128, 1, f))
            FatalError("could not read header");
        theHeader.yMax++; theHeader.xMax++;
        mySize = (theHeader.yMax- theHeader.yMin) * (theHeader.xMax-theHeader.xMin) + 5;

		if (*theBitmap == NULL) {
        	if ((tempBitmap = malloc(mySize))==NULL)
	            FatalError("could not allocate bitmap");
			}
		else {
			tempBitmap = *theBitmap;
			}
        *((int *)tempBitmap) = theHeader.xMax - theHeader.xMin;
        *((int *)tempBitmap+1) = theHeader.yMax - theHeader.yMin;

        index = 4;
        while (index <= mySize) {
            data = getc(f);
            if (data >= 192 && data <= 255) {
                count = data-192;
                data = getc(f);
                while(count -- > 0) {
                    *(tempBitmap+index) = data;
                    index++;
                    }
                }
            else {
                *(tempBitmap+index) = data;
                index ++;
                }
            }

        fseek(f, -768, SEEK_END);
        if (!fread(tempPalette, 768, 1, f))
            FatalError("could not read palette");

        for (index=0; index<256; index++) {
            tempPalette->theColors[index].r = tempPalette->theColors[index].r >> 2;
            tempPalette->theColors[index].g = tempPalette->theColors[index].g >> 2;
            tempPalette->theColors[index].b = tempPalette->theColors[index].b >> 2;
            }

        fclose(f);
        *theBitmap = tempBitmap;

        return TRUE;       

        }
    return FALSE;
    }

void FadeIn(Palette *thePalette, unsigned long theDelay) {
    Palette nullPalette;
    int index;
    float tempFloat;
    RGBColor nullColor = {0,0,0};

    for(tempFloat=0.0; tempFloat<=1.0; tempFloat+=0.05) {
        for(index=0; index<256; index++) {
            nullPalette.theColors[index].r = tempFloat*thePalette->theColors[index].r;
            nullPalette.theColors[index].g = tempFloat*thePalette->theColors[index].g;
            nullPalette.theColors[index].b = tempFloat*thePalette->theColors[index].b;
            }

        SetPalette(&nullPalette);
        MyDelay(theDelay);
        }
    }

void FadeOut(unsigned long theDelay) {
    Palette nullPalette, thePalette;
    int index;
    float tempFloat;

    GetPalette(&thePalette);

    for (tempFloat=1.0; tempFloat>=0.0; tempFloat -=0.05) {
        for(index=0; index<256; index++) {
            nullPalette.theColors[index].r = tempFloat*thePalette.theColors[index].r;
            nullPalette.theColors[index].g = tempFloat*thePalette.theColors[index].g;
            nullPalette.theColors[index].b = tempFloat*thePalette.theColors[index].b;
            }
        SetPalette(&nullPalette);
        MyDelay(theDelay);
        }

    }

void SlideIn(char *theBackground, char *theMenu, long theDelay) {
	fixed factor;

	SetDrawDest(ScratchSeg);
	FillScreen(0);

	for(factor=1; factor<256 & !CheckKey(); factor++) {
		FillScreen(0);
		TSDrawBitmap(theBackground, 255-factor, 255-factor, 256+(255-factor), 256+(255-factor));
		TSDrawBitmap(theMenu, 79-(255-factor), 49-(255-factor), factor, factor);
		ScreenToScreen(ScreenSeg, ScratchSeg);
		MyDelay(theDelay);
		}
	}

void SlideOut(char *theBackground, char *theMenu, long theDelay) {
	fixed factor;

	SetDrawDest(ScratchSeg);
	FillScreen(0);

	for(factor=256; factor > 1 & !CheckKey(); factor--) {
		FillScreen(0);
		TSDrawBitmap(theBackground, 255-factor, 255-factor, 256+(255-factor), 256+(255-factor));
		TSDrawBitmap(theMenu, 79-(255-factor), 49-(255-factor), factor, factor);
		ScreenToScreen(ScreenSeg, ScratchSeg);
		MyDelay(theDelay);
		}
	}

void DrawStatusBar(char *statusBar) {
	
	DrawBitmap(statusBar, 0, 180);
	}