#include <stdio.h>
#include <malloc.h>
#include "graphics.h"
#include "utils.h"
#include "system.h"
#include "math.h"

const segment ScreenSeg = 0xA000;
const RGBColor nullColor = {0,0,0};

void main() {
	Palette thePalette, nullPalette;
	char *theBackground, *theMenu, *theShadow;
	col colorIndex;
	void *tempSeg = (void *)((long)GetScratchSeg()<<16);
	long factor, factorV;
	int tempInt;

	if (!LoadPCX("f:\\galaga\\data\\image2.pcx", &theBackground, &thePalette))
		FatalError("Could not load background!");
	if (!LoadPCX("f:\\galaga\\data\\menu.pcx", &theMenu, &nullPalette))
		FatalError("Could not load menu1");
	if (!LoadPCX("f:\\galaga\\data\\shadow.pcx", &theShadow, &nullPalette))
		FatalError("Could not load menu2");
	
	for (colorIndex=255; colorIndex>0; colorIndex--)
		nullPalette.theColors[colorIndex] = nullColor;

	SetMode13();
	SetDrawDest(ScreenSeg);
	SetPalette(&nullPalette);

	BufferToScreen(theBackground);
	FadeIn(&thePalette, 5000);
	getch();
	
	for(factor=1; factor<256; factor++) {
		SetDrawDest(GetScratchSeg());
		FillScreen(0);
		TSDrawBitmap(theBackground, 255-factor, 255-factor, 256+(255-factor), 256+(255-factor));
		TSDrawBitmap(theMenu, 79-(255-factor), 49-(255-factor), factor, factor);
		SetDrawDest(ScreenSeg);
		ScreenToScreen(tempSeg);
		MyDelay(1000);
		}


	getch();
	FadeOut(&thePalette, 5000);
	SetModeText();

	free(theBackground);
	free(theMenu);
	free(theShadow);

    }