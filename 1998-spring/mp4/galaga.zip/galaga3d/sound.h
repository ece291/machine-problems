#ifndef __SOUND__
#define __SOUND__

typedef struct {
	char far *sound;		 // address of audio data. IMPORANT SEE NOTE BELOW!!!!!!!!!!
	unsigned short sndlen; // Length of audio sample.
	short far *IsPlaying; // Address of play status flag.
	short frequency;	// Playback frequency. recommended 11khz.
} SoundStruc;

extern void DigPlay(SoundStruc far *theSoundStruc);

/*extern SetupMarvin(void);
extern void PlayMarvin(void);
extern SetupGuns(void);
extern void PlayGuns(void);
extern SetupExplode(void);
extern void PlayExplode(void);
extern SetupFeature(void);
extern void PlayFeature(void);*/


#endif
