#include <stdio.h>
#include <malloc.h>
#include "graphics.h"
#include "utils.h"

const segment ScreenSeg = 0xA000;
const RGBColor nullColor = {0,0,0};

void main() {
    char *theBackground, *theTitle;
    Palette thePalette;
    Palette nullPalette;
    int temp,tempa;
    fixed factor;
    void *tempSeg;

    if (!LoadPCX("f:\\galaga\\data\\image8.pcx", &theTitle, &thePalette))
        exit(-1);
    printf("picture at %p; size %u\n", theTitle, _msize(theTitle));
    getch();
    if (!LoadPCX("f:\\galaga\\data\\image2.pcx", &theBackground, &thePalette))
        exit(-1);
    printf("picture at %p; size %u\n", theBackground, _msize(theBackground));
    getch();

    SetMode13();

    for (temp=0; temp<256; temp++) {
        nullPalette.theColors[temp] = nullColor;
        }
    
    SetPalette(&nullPalette);
    SetDrawDest(ScreenSeg);
    BufferToScreen(theBackground);

    FadeIn(&thePalette, 25000);
    getch();
//    for(temp=0; temp<50; temp++)
//  AddDrawBitmap(theTitle,(320-146)/2, (200-54)/2);
    tempSeg = (long)GetScratchSeg() << 16;
    for(tempa=0; tempa<=2; tempa++){
        for(factor=600; factor>=1; factor-=20) {
            SetDrawDest(GetScratchSeg());
            BufferToScreen(theBackground);
            TSDrawBitmap(theTitle, 130, 80, factor, factor );
            SetDrawDest(ScreenSeg);
            ScreenToScreen(tempSeg);
            MyDelay(50000);
        }
        for(factor=1; factor<=600; factor+=100) {
            SetDrawDest(GetScratchSeg());
            BufferToScreen(theBackground);
            TSDrawBitmap(theTitle, 130, 80, factor , factor);
            SetDrawDest(ScreenSeg);
            ScreenToScreen(tempSeg);
            MyDelay(50000);
        }
        for (temp=80; temp >= -100; temp-=10) {
            SetDrawDest(GetScratchSeg());
            BufferToScreen(theBackground);
            TSDrawBitmap(theTitle, 130, temp, factor , factor);
            SetDrawDest(ScreenSeg);
            ScreenToScreen(tempSeg);
            MyDelay(50000);
        }
        for (temp=-100; temp <= 220; temp+=10) {
            SetDrawDest(GetScratchSeg());
            BufferToScreen(theBackground);
            TSDrawBitmap(theTitle, 130, temp, factor , factor);
            SetDrawDest(ScreenSeg);
            ScreenToScreen(tempSeg);
            MyDelay(50000);
        }
        for (temp=220; temp >= 80; temp-=10) {
            SetDrawDest(GetScratchSeg());
            BufferToScreen(theBackground);
            TSDrawBitmap(theTitle, 130, temp, factor , factor);
            SetDrawDest(ScreenSeg);
            ScreenToScreen(tempSeg);
            MyDelay(50000);
        }
        for (temp=130; temp <= 350; temp+=10) {
            SetDrawDest(GetScratchSeg());
            BufferToScreen(theBackground);
            TSDrawBitmap(theTitle, temp, 80, factor , factor);
            SetDrawDest(ScreenSeg);
            ScreenToScreen(tempSeg);
            MyDelay(50000);
        }
        for (temp=350; temp >= -100; temp-=10) {
            SetDrawDest(GetScratchSeg());
            BufferToScreen(theBackground);
            TSDrawBitmap(theTitle, temp, 80, factor , factor);
            SetDrawDest(ScreenSeg);
            ScreenToScreen(tempSeg);
            MyDelay(50000);
        }
        for (temp=-100; temp <= 130; temp+=10) {
            SetDrawDest(GetScratchSeg());
            BufferToScreen(theBackground);
            TSDrawBitmap(theTitle, temp, 80, factor , factor);
            SetDrawDest(ScreenSeg);
            ScreenToScreen(tempSeg);
            MyDelay(50000);
        }


    }
    getch();
    FadeOut(&thePalette, 2000);
    SetModeText();
    free(theBackground);
    free(theTitle);
    }

