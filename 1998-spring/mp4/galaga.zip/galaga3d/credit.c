void DrawName(int y, char *thepic){
	int temp;
	fixed yfactor, xfactor;
	SetDrawDest(ScratchSeg);
	ScreentoScreen(ScratchSegB, ScreenSeg);
	for (yfactor=1000; yfactor>256; yfactor-=2){
		temp=*((int *)thepic+1)*256/(yfactor*2);
		ScreentoScreen(ScratchSeg, ScratchSegB);
		TSDrawBitmap(thepic, 30, y-temp , (512-yfactor), yfactor);
		ScreenToScreen(ScreenSeg, ScratchSeg);
		MyDelay(1500);
	}
}


void ShowCredit(){
	char *Rachana=NULL, *Rachanapic=NULL , *Niels=NULL, *Nielspic=NULL,
			*Jon=NULL, *Jonpic=NULL, *Minn=NULL, *Minnpic=NULL;
	Palette nullPalette, thePalette;
	char *letterG = NULL, *letterA = NULL, *letterL = NULL;
	char *shapes[6];
	char *theBackground= NULL, *theTitle=NULL;
	int posX[6] = {85, 109, 137, 156, 182, 206};
	int	factor[6] = {0, -20, -40, -60, -80, -100};
	int temp;

	if (!LoadPCX("data\\image2.pcx", &theBackground, &thePalette))
		FatalError("Could not load theBackground");
	SetDrawDest(ScreenSeg);
	SetPalette(&thePalette);
	BufferToScreen(theBackground);
	free(theBackground);

	if (!LoadPCX("data\\3d.pcx", &theTitle, &nullPalette))
		FatalError("Could not load G");
	if (!LoadPCX("data\\g.pcx", &letterG, &nullPalette))
		FatalError("Could not load G");
	if (!LoadPCX("data\\a.pcx", &letterA, &nullPalette))
		FatalError("Could not load A");
	if (!LoadPCX("data\\l.pcx", &letterL, &nullPalette))
		FatalError("Could not load L");

	shapes[0] = letterG; shapes[1] = letterA; shapes[2] = letterL;
	shapes[3] = letterA; shapes[4] = letterG; shapes[5] = letterA;

	ScreenToScreen(ScratchSegB, ScreenSeg);
	SetDrawDest(ScratchSeg);
	while (factor[5] < 256 ) {
		ScreenToScreen(ScratchSeg, ScratchSegB);
		for(temp=0; temp<6; temp++) {
			factor[temp]+= 1;
			if (factor[temp] > 256)
				factor[temp] = 256;
			if (factor[temp]>0)
				TSDrawBitmap(shapes[temp], posX[temp], 5, factor[temp], factor[temp]);
			}
		ScreenToScreen(ScreenSeg, ScratchSeg);
	}

	SetDrawDest(ScreenSeg);
	for(temp=0; temp<40 & !CheckKey(); temp++) {
			AddDrawBitmap(theTitle, 165, 25);
			MyDelay(1500);
			}
	free(letterG); free(letterA); free(letterL);free(theTitle);

	if (!LoadPCX("data\\Jon.pcx", &Jon, &nullPalette))
		FatalError("Could not load Jon");
	DrawName(80, Jon);
	DrawName(110, Jon);
	DrawName(140, Jon);
	DrawName(170, Jon);

	free(Jon);
	getch();
}
