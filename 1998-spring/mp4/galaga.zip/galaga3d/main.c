//(set tabs=4 spaces)
/*===================================================
  Galaga 3D
  UIUC - ECE291, May 1997
  Prof. Lockwood

 by:
  Niels Gabel, Rachana Gupta, Minn Thein, & Jon Rachwalski

 Production Notes:
	I guess we tried to bite off more than we could collectively chew
	with this one.. (let that be a note to posterity) We might have been
	able to pull it off with one more week, but instead, the project
	remains partly unfinished. Let me point out what is missing for the
	inquisitive:
		o enemies:
			1) They should be depth sorted! The routine is there, just not tied in...
			2) I would like to have had more ways for the enemy ships to move
			3) The enemies dont shoot at you yet
			4) You cant shoot them down. The Shoot() routine miscalculates hits
			   i.e. (you always miss)
		o transitions:
			1) there should be transitions when a level starts/ends
		o sound/music:
			1) there are only 2 sound effects- and none in the gameplay
		o gameplay:
			1) pressing a key shouldn't make the game quit.. should bring up a menu
			   instead

	These are minor points.. maybe i will get around to finishing them later.. but
	if you are reading this... well.. then i didn't.
	One more thing: we need to use memory better.. currently, the program runs out and quits!
  ===================================================*/

#include <stdio.h>
#include <malloc.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <math.h>
#include <process.h>
#include "graphics.h"		//interface to graphics routines
#include "mysystem.h"		//mouse, interrupt, MIDI, sound routine interface
#include "utils.h"			//number conversion, error, key buffer routines
#include "ship.h"			//interface to enemy management/control routines


/*==============================
	constants       
  ==============================*/

const char cursorFile[] = "data\\cursor.pcx";
const char menuFile[] = "data\\menu.pcx";
const char fontFile[] = "data\\font.pcx";
const char backgroundFile[] = "data\\image2.pcx";
const char statBarFile[] = "data\\statbar.pcx";

const int levelCount = 1;	//number of levels to play
const int Menu_music = 0;	//sequence numbers used by MIDPAK
const int Game_music = 1;

const RGBColor BlackColor = {0,0,0};
const mySegment ScreenSeg = 0xA000;

/*==============================
	globals
  ==============================*/

mySegment ScratchSeg, ScratchSegB;				// ptrs to scratch segs from asm
char *theFont, *statBarStorage, *statusBar;		// global bitmap storgage
char *theMusic;									// where music is stored

int score=0, shield=45;
extern float zmax;		// from graphics.c

/*==============================
	support routines
  ==============================*/

//prototypes as necessary
void FlyingLetters();
void Explosion();
int MainMenu();
void PlayGame();
void HiLight (char pos);
void DeHiLight (char pos);
void ShowCredit();

/*----------------------------------------------------
-	Shoot()
-	when mouse is clicked, determines whether an enemy ship is hit
	and takes appropriate action
  ----------------------------------------------------*/
void Shoot() {
	int index, foundFlag=0;
	fixed coords = MousePos();		//get mouse pos from asm
	float factor;

 //extract mouse coords x, y
	fixed clickX = ((coords>>16) - 160)*256;
	fixed clickY = ((coords & 0x0000FFFF ) - 100)*256;

 // search shipDrawBuffer to find any suitable ships
	index=31;
	while (index>0 && !foundFlag) {
		if (theDrawBuffer->data[index].valid) {
			factor = (zmax - (float)theDrawBuffer->data[index].z)/zmax;
		 //is the current ship under the mouse cursor?
			if ((clickX > theDrawBuffer->data[index].x) && (clickX < theDrawBuffer->data[index].x+32.0*256.0/factor))
			if ((clickY > theDrawBuffer->data[index].y) && (clickY < theDrawBuffer->data[index].y+32.0*256.0/factor)) {
			 	//if yes, note that we found a match
				foundFlag = (1==1);

				//calculate enemy's new hit points
				if ((--(theDrawBuffer->data[index].theShip->hits)) < 0) {
					score += theDrawBuffer->data[index].theShip->points;
					//program him to self destruct if hits are < 0
					theDrawBuffer->data[index].theShip->program = 9;
					}
				}
			}
		index--;
		}
	}


/*----------------------------------------------------
-	PlayLevel
-	Plays one level of the game
  ----------------------------------------------------*/
int PlayLevel(FILE *levelFile, Palette *thePalettePtr, char *theFloor, char *theCeiling, char *theShips) {
	char *statusBar = NULL;
	Palette nullPalette;
	int maxTime, temp;
	Ship *pendingShip;

	//load the status bar picture
	if (!LoadPCX(statBarFile, &statusBar, &nullPalette))
		FatalError(statBarFile);

	fscanf(levelFile, "%u\n", &maxTime);	//read how long the level plays for
	ClearShipBuffer();						//erase all ships in the draw buffer

	SetDrawDest(ScratchSeg);				//we're draw to the scratch segment
	InstallTimeInt();						/*start timer ISR (floor, mouse, enemies)
											  timer ISR also copies from scratch seg to
											  main screen*/
	MouseCtrl(0, 0, 305, 165);				//set mouse bounds
	ShowMouse();							//show the mouse cursor

	DrawStatusBar();						//show status bar
	FadeIn(thePalettePtr, 25000);
	
	//loop until we reach max time or are out of ship data in the level file or someone
	//presses a key
	while ((GetTime() < maxTime) && (!feof(levelFile)) && (!CheckKey())) {
		//read the next ship from the config file
		if ((pendingShip = FReadShip(levelFile))==NULL)
			FatalError("Could not read ship information");

		//loop until that should should be inserted in the level
		while ((GetTime() < (pendingShip->creationTime)) && (!CheckKey())) {
			//move all ships
			UpdateShips();

			if (MouseButton() & 0x0001)	Shoot();
			if (MouseButton() & 0x0002) {Splash(); Shoot();}
			MyDelay(20000);
			}
		//when the ship creation time is reached, insert the pending ship
		AddShipToDrawBuffer(pendingShip);
		}

	//loops just until time runs out... if we get here, there are no more ships in the
	//level file
	while ((GetTime() < maxTime) && (!CheckKey())) {
		UpdateShips();
		if (MouseButton() & 0x0001)	Shoot();
		if (MouseButton() & 0x0002) {Splash();	Shoot();}
		MyDelay(20000);
		}

	//destroy any ships that are left when level ends

	for(temp=0; temp<32; temp++)
		if ((theDrawBuffer->data[temp].valid) != 0)
			DestroyShip(0);

	FadeOut(25000);
	DeInstallTime();		// uninstall timer ISR

	return 0;
	}


/*----------------------------------------------------
-	PlayGame()
-	Plays all levels by calling PlayLevel() (above)
  ----------------------------------------------------*/
void PlayGame() {
	//vars
	FILE *levelFile;
	char filename[255], floorFilename[255], ceilingFilename[255], shipFilename[255], errorMsg[255];
	char tempStr[255];
	char *tempStrPtr;
	int levelNum=1, diedFlag=0;
	char *mouseCsr = GetMouseBuffer(), *theFloor = NULL, *theCeiling = NULL;
	char *theShips = GetShipBuffer();
	Palette thePalette, nullPalette;
	
	//load mouse cursor into mouse cursor buffer (at end of ScratchSeg)
	if (!LoadPCX(cursorFile, &mouseCsr, &nullPalette)) {
		FatalError(strcat("Could not load ", cursorFile));
		}

	//clear the keyboard buffer
	while (CheckKey())
		getch();
	
	//loop through each level while we haven't died
	for (levelNum=1; (levelNum <= levelCount) & !diedFlag; levelNum++) {
		itoa(levelNum, tempStr, 10);
		strcpy(filename, "data\\level");
		strcat(filename, tempStr); strcat(filename, ".lvl");
		if ((levelFile = fopen(filename, "r"))==NULL)
			FatalError("Could not open file");

		//read graphics specs from level file
		fscanf(levelFile, "%s\n", floorFilename);
		fscanf(levelFile, "%s\n", ceilingFilename);
		fscanf(levelFile, "%s\n", shipFilename);
		fscanf(levelFile, "%s\n", shipFilename);

		theFloor = NULL; theCeiling = NULL;					//have to do this for LoadPCX
		if (!LoadPCX(floorFilename, &theFloor, &nullPalette))
			FatalError("");
		if (!LoadPCX(ceilingFilename, &theCeiling, &nullPalette))
			FatalError("");
		if (!LoadPCX(shipFilename, &theShips, &thePalette))
			FatalError("");
		SetFloorCeiling(theFloor, theCeiling);		//install floor+ceiling bitmaps
		
		
		switch (PlayLevel(levelFile, &thePalette, theFloor, theCeiling, theShips)) {
			case 0: diedFlag=1; break;
			case 1: diedFlag=0; break;
			default: break;
			}

		//dont free mouseCsr or ShipBuffer... it's in ScratchSeg
		free(theFloor); free(theCeiling);
		fclose(levelFile);
		}		
	}

/*----------------------------------------------------
-	DrawName
-	Draws a name on the credits screen
  ----------------------------------------------------*/
void DrawName(int y, char *thepic){
	int temp;
	fixed yfactor, xfactor;
	SetDrawDest(ScratchSeg);
	ScreentoScreen(ScratchSegB, ScreenSeg);

	//adjust scaling factor to 1 (fxp)
	for (yfactor=2000; yfactor>256; yfactor-=4){
		//calculate xfactor based in yfactor
		xfactor = (2000-yfactor)*256/1744;
		temp=*((int *)thepic+1)*256/(yfactor*2);
		ScreentoScreen(ScratchSeg, ScratchSegB);
		TSDrawBitmap(thepic, 30, y-temp , xfactor, yfactor);
		ScreenToScreen(ScreenSeg, ScratchSeg);
		MyDelay(1500);
	}
}


/*----------------------------------------------------
-	ShowCredit
-	Draws credits
  ----------------------------------------------------*/
void ShowCredit(){
	char *name;
	Palette nullPalette, thePalette;
	char *letterG = NULL, *letterA = NULL, *letterL = NULL;
	char *theBackground= NULL, *theTitle=NULL;
	SoundStruc hitSound;

	//vars for flying letter routine
	char *shapes[6];
	int posX[6] = {85, 109, 137, 156, 182, 206};
	int	factor[6] = {0, -30, -60, -90, -120, -150};
	int v[6] = {1,1,1,1,1,1};
	int temp;

	if (!LoadPCX("data\\back2.pcx", &theBackground, &thePalette))
		FatalError("Could not load theBackground");
	SetDrawDest(ScreenSeg);				//draw to scratch seg
	SetPalette(&thePalette);			//black out colors
	BufferToScreen(theBackground);		//draw background
	free(theBackground);				//dispose of it

	theTitle = GetShipBuffer();
	letterG = GetShipBuffer() + 1796;
	letterA = GetShipBuffer() + 2596;
	letterL = GetShipBuffer() + 3396;

	if (!LoadPCX("data\\3d1.pcx", &theTitle, &nullPalette))
		FatalError("Could not load 3D");
	if (!LoadPCX("data\\g2.pcx", &letterG, &nullPalette))
		FatalError("Could not load G");
	if (!LoadPCX("data\\a2.pcx", &letterA, &nullPalette))
		FatalError("Could not load A");
	if (!LoadPCX("data\\l2.pcx", &letterL, &nullPalette))
		FatalError("Could not load L");
	
	hitSound.sound = GetShipBuffer() + 3896;
	hitSound.frequency=22100;
	LoadSound("data\\metlhit.wav", &hitSound);

	shapes[0] = letterG; shapes[1] = letterA; shapes[2] = letterL;
	shapes[3] = letterA; shapes[4] = letterG; shapes[5] = letterA;

	//the following is from the FlyingLetters routine...
	ScreenToScreen(ScratchSegB, ScreenSeg);
	SetDrawDest(ScratchSeg);
	while (factor[5] < 256 ) {
		ScreenToScreen(ScratchSeg, ScratchSegB);
		for(temp=0; temp<6; temp++) {
			factor[temp]+= v[temp];
			if (factor[temp] > 256) {
				factor[temp] = 256;
				DigPlay(&hitSound);
				v[temp]=0;
				}
			if (factor[temp]>0)
				TSDrawBitmap(shapes[temp], posX[temp], 5, factor[temp], factor[temp]);
			}
		ScreenToScreen(ScreenSeg, ScratchSeg);
	}
	
	SetDrawDest(ScreenSeg);
    TDrawBitMap(theTitle, 165, 25);

	//draw the names
	name=GetShipBuffer();
	if (!LoadPCX("data\\Jon1.pcx", &name, &nullPalette))
		FatalError("Could not load Jon");
	DrawName(80, name); free(name); name=NULL;
	if (!LoadPCX("data\\minn1.pcx", &name, &nullPalette))
		FatalError("Could not load Minn");
	DrawName(110, name); free(name); name=NULL;
	if (!LoadPCX("data\\niels1.pcx", &name, &nullPalette))
		FatalError("Could not load Niels");
	DrawName(140, name); free(name); name=NULL;
	if (!LoadPCX("data\\Rachana.pcx", &name, &nullPalette))
		FatalError("Could not load Rachana");
	DrawName(170, name);
	getch();	//pause here
}

/*----------------------------------------------------
-	InitGame
-	Prefroms game initialization
  ----------------------------------------------------*/
void InitGame() {
	Palette nullPalette;
	ScratchSeg = GetScratchSeg();				//set global c ptrs to scratch video
	ScratchSegB = GetScratchSegB();

	if (!LoadPCX(fontFile, &theFont, &nullPalette))			//load font
		FatalError(fontFile);
	if (!LoadPCX(statBarFile, &statusBar, &nullPalette))	//load status bar
		FatalError("could not load status bar");
	statBarStorage = (char *)((long)ScratchSegB<<16);
	theDrawBuffer = GetShipDrawBuffer();

	InitMidi();
	SetMode13(); 
	}

/*----------------------------------------------------
-	GameShutdown
-	Performs final cleanup
  ----------------------------------------------------*/
void GameShutdown() {
	SetModeText();
	free(theFont);
	free(statusBar);
	free(statBarStorage);
	free(theMusic);
	MIDIStop();
	}

/*----------------------------------------------------
-	Intro
-	Plays game intro
  ----------------------------------------------------*/
void Intro() {
	Palette nullPalette, thePalette;
	char *theBackground = NULL, *theMenu = NULL, *theTitle2 = NULL, *intro2=NULL;
	col colorIndex;
	fixed factor;
	int tempInt;
	SoundStruc tempSound;
	char *theSong = LoadMIDI("data\\descent.xmi");

	PlaySequence(0);
	MIDIStop();

	for (colorIndex=255; colorIndex>0; colorIndex--)
		nullPalette.theColors[colorIndex] = BlackColor;
 
	SetDrawDest(ScreenSeg);
	FadeOut(5000);
	intro2 = GetShipBuffer();

	if (!LoadPCX("data\\intro2.pcx", &intro2, &thePalette))
		FatalError("data\\intro2.pcx");
	BufferToScreen(intro2);
	FadeIn(&thePalette, 5000);
	MyDelay(1000000);
	FadeOut(5000);
	
	if (!LoadPCX("data\\intro1.pcx", &intro2, &thePalette))
		FatalError("data\\intro1.pcx");
	BufferToScreen(intro2);
	FadeIn(&thePalette, 5000);
	MyDelay(1000000);
	FadeOut(5000);

	free(intro2);
	FillScreen(0);

	tempSound.sound=GetShipBuffer();
	LoadSound("data\\feature.wav", &tempSound);
	tempSound.frequency = 11000;
	DigPlay(&tempSound);
	MyDelay(1000000);
	
	PlaySequence(0);

	theMenu=Seg2Ptr(GetScratchSegB());

	theMenu = GetShipBuffer();
	if (!LoadPCX(menuFile, &theMenu, &nullPalette))
		FatalError("could not load menu pcx");
	if (!LoadPCX("data\\3d.pcx", &theTitle2, &nullPalette))
		FatalError("could not load 3d.pcx");
	if (!LoadPCX("data\\image2.pcx", &theBackground, &thePalette))
		FatalError("could not load menu background");

	FadeIn(&thePalette, 5000);

	SlideIn(theBackground, theMenu, 9900);

	if (!CheckKey()) {
		FlyingLetters();
		SetDrawDest(ScreenSeg);
		for(tempInt=0; tempInt<40 & !CheckKey(); tempInt++) {
			AddDrawBitmap(theTitle2, 165, 100);
			MyDelay(15000);
			}

		for(tempInt=0; tempInt<100 && !CheckKey(); tempInt++)
			MyDelay(10000);

		if (!CheckKey())
			Explosion();
		
		if (!CheckKey()) {
			GetBitmap(theMenu, 80, 50, 160, 100, ScreenSeg);
			SlideOut(theBackground, theMenu, 5000);
			}
		SetDrawDest(ScreenSeg);
		if (!CheckKey()) {
			FillScreen(0);
			}
		}
	FadeOut(5000);
	FillScreen(0);

	free(theBackground);
	}


/*----------------------------------------------------
-	FlyingLetters();
-	Shows the galaga logo flying on screen
  ----------------------------------------------------*/
void FlyingLetters() {
	Palette nullPalette;
	char *letterG = NULL, *letterA = NULL, *letterL = NULL;
	char *shapes[6];
	int posX[6] = {85, 109, 137, 156, 182, 206};
	int	factor[6] = {0, -50, -100, -150, -200, -230};
	int v[6] = {1,1,1,1,1,1};
	int temp;
	SoundStruc hitSound;
 
	letterG = GetShipBuffer();
	letterA = GetShipBuffer()+800;
	letterL = GetShipBuffer()+1600;

	hitSound.sound = GetShipBuffer() + 2100;
	LoadSound("data\\metlhit.wav", &hitSound);
	hitSound.frequency=22100;

	if (!LoadPCX("data\\g.pcx", &letterG, &nullPalette))
		FatalError("Could not load G");
	if (!LoadPCX("data\\a.pcx", &letterA, &nullPalette))
		FatalError("Could not load A");
	if (!LoadPCX("data\\l.pcx", &letterL, &nullPalette))
		FatalError("Could not load L");

	shapes[0] = letterG; shapes[1] = letterA; shapes[2] = letterL;
	shapes[3] = letterA; shapes[4] = letterG; shapes[5] = letterA;

	ScreenToScreen(ScratchSegB, ScreenSeg);
	SetDrawDest(ScratchSeg);
	while (factor[5] < 256 & !CheckKey()) {
		ScreenToScreen(ScratchSeg, ScratchSegB);
		for(temp=0; temp<6; temp++) {
			factor[temp]+= v[temp];
			if (factor[temp] > 256) {
				factor[temp] = 256;
				v[temp]=0;
				DigPlay(&hitSound);
				}
			if (factor[temp]>0)
				TSDrawBitmap(shapes[temp], posX[temp], 82, factor[temp], factor[temp]);
			}
		ScreenToScreen(ScreenSeg, ScratchSeg);
		MyDelay(2500);
		}
	}


/*----------------------------------------------------
-	Explosion
-	Explosion effect show in introduction
  ----------------------------------------------------*/
void Explosion() {
	char *burst = GetShipBuffer();
	Palette nullPalette;
	int tempInt, currDot;
	int	vx[450], vy[450], x[450], y[450];

	LoadPCX("data\\burst.pcx", &burst, &nullPalette);

	ScreenToScreen(ScratchSegB, ScreenSeg);
	SetDrawDest(ScratchSeg);

	for(currDot=0; currDot<450 & !CheckKey(); currDot++) {
		x[currDot] = (rand() % 580) + 340;
		y[currDot] = (rand() % 252) + 328;
		vx[currDot] = (rand() % 100) - 50;
		if (!vx[currDot])
			vx[currDot]++;
		vy[currDot] = -(rand() % 140);
		if (!vy[currDot])
			vy[currDot]++;
		}

	Splash();
	for(tempInt=0; tempInt<450 & !CheckKey(); tempInt++) {
		ScreenToScreen(ScratchSeg, ScratchSegB);
		for(currDot=0; currDot<450; currDot++) {
			x[currDot] += (vx[currDot]>>5);
			y[currDot] += (vy[currDot]>>5);
			vy[currDot]++;

			if ((y[currDot] > 0) && (y[currDot]<784) && (x[currDot]>0) && (x[currDot]<1264)) {
				TDrawBitmap(burst, (x[currDot]>>2), (y[currDot]>>2));
				}
			}
		ScreenToScreen(ScreenSeg, ScratchSeg);
		MyDelay(5000);
		}
	}


/*----------------------------------------------------
-	HiLight
-	Hilights menu item
  ----------------------------------------------------*/
void HiLight (char pos) {
	switch (pos) {
		case 0 : SetTextXY(14+80, 41+50); DrawText(theFont, "\001\001PLAY THE GAME\001\001", 255,23);break;
		case 1 : SetTextXY(14+80, 51+50); DrawText(theFont, "\001\001INSTRUCTIONS\001\001\001", 255, 23); break;
		case 2 : SetTextXY(14+80, 61+50); DrawText(theFont, "\001\001CREDITS\001\001\001\001\001\001\001\001", 255, 23);break;
		case 3 : SetTextXY(14+80, 71+50); DrawText(theFont, "\001\001QUIT\001\001\001\001\001\001\001\001\001\001\001", 255, 23);break;
	}
	return;
}


/*----------------------------------------------------
-	DeHilight
-	Dehilites menu option
  ----------------------------------------------------*/
void DeHiLight (char pos) {
	switch (pos) {
		case 0 : SetTextXY(14+80, 41+50); DrawText(theFont, "\001\001PLAY THE GAME\001\001", 255,148);break;
		case 1 : SetTextXY(14+80, 51+50); DrawText(theFont, "\001\001INSTRUCTIONS\001\001\001", 255, 148); break;
		case 2 : SetTextXY(14+80, 61+50); DrawText(theFont, "\001\001CREDITS\001\001\001\001\001\001\001\001", 255, 148);break;
		case 3 : SetTextXY(14+80, 71+50); DrawText(theFont, "\001\001QUIT\001\001\001\001\001\001\001\001\001\001\001", 255, 148);break;
	}
	return;
}


/*----------------------------------------------------
-	MainMenu
-	Handles main menu interface
  ----------------------------------------------------*/
int MainMenu() {
	char *theBackground = NULL, *theMenu = NULL, *theFont = NULL, *theTitle = NULL;
	unsigned char tempChar;
	Palette nullPalette, thePalette;
	col colorIndex;
	int returnVal=-1;
	char currentpos=0;

	LoadPCX(backgroundFile, &theBackground, &thePalette);
	LoadPCX(menuFile, &theMenu, &nullPalette);
	LoadPCX(fontFile, &theFont, &nullPalette);
	LoadPCX("data\\gsmall.pcx", &theTitle, &nullPalette);

	for(colorIndex=255; colorIndex>0; colorIndex--)
		nullPalette.theColors[colorIndex] = BlackColor;

	SetDrawDest(ScratchSeg);
	DrawBitmap(theMenu, 0, 0);
	TDrawBitmap(theTitle, 26, 3);	
	SetTextXY(14, 41); DrawText(theFont, "\001\001PLAY THE GAME\001\001", 255,148);
	SetTextXY(14, 51); DrawText(theFont, "\001\001INSTRUCTIONS\001\001\001", 255, 148);
	SetTextXY(14, 61); DrawText(theFont, "\001\001CREDITS\001\001\001\001\001\001\001\001", 255, 148);
	SetTextXY(14, 71); DrawText(theFont, "\001\001QUIT\001\001\001\001\001\001\001\001\001\001\001", 255, 148);
	GetBitmap(theMenu, 0, 0, 160, 100, ScratchSeg);

	if (!CheckKey()) {
		SetPalette(&thePalette);
		SlideIn(theBackground, theMenu, 5000);
		}

	SetDrawDest(ScreenSeg);

	if (CheckKey()) {
		FadeOut(5000);
		BufferToScreen(theBackground);
		DrawBitmap(theMenu, 80, 50); 
		FadeIn(&thePalette, 5000);
		SetPalette(&thePalette);
		}

	HiLight(currentpos);

	while (CheckKey())		//clears keyboard buffer;
		getch();

	do {
		switch (tempChar = toupper(getch())) {
			case 0: case 0xe0:
				DeHiLight(currentpos);
				switch (tempChar = getch()) {
					case 80: if ((++currentpos)>3) currentpos = 0; break;
					case 72: if ((--currentpos)<0) currentpos = 3; break;
					}
				HiLight(currentpos);
				break;
			case 13:	
					switch (currentpos){
						case 0: returnVal = 1; break;
						case 1: returnVal = 3; break;
						case 2: returnVal = 2; break;
						case 3: returnVal=0; break;
					}
					break;

			case 27: 	returnVal=0; break;
			default: 	returnVal = -1; break;
			}
		} while (returnVal == -1);

	FadeOut(5000);
	free(theBackground); free(theMenu); free(theFont);
	return returnVal;
	}


/*----------------------------------------------------
-	Main
-	main routine
  ----------------------------------------------------*/
void main() {
	int quitFlag=0;
	ShipDrawData testData;

	InitGame();
	Intro();

	do {
		switch (MainMenu()) {
			case 0:	quitFlag = (1==1); break;
			case 1: PlayGame(); break;
			case 2: ShowCredit(); break;
			default: break;
			}
		} while (!quitFlag);
	FadeOut(5000);
	GameShutdown();
	}
