#ifndef __MYSYSTEM__
#define __MYSYSTEM__

#include "utils.h"
#include "graphics.h"
#include "ship.h"

typedef struct {
	char far *sound;		 // address of audio data. IMPORANT SEE NOTE BELOW!!!!!!!!!!
	unsigned short sndlen; // Length of audio sample.
	short far *IsPlaying; // Address of play status flag.
	short frequency;	// Playback frequency. recommended 11khz.
} SoundStruc;

extern void DigPlay(SoundStruc far *theSoundStruc);

/*extern SetupMarvin(void);
extern void PlayMarvin(void);
extern SetupGuns(void);
extern void PlayGuns(void);
extern SetupExplode(void);
extern void PlayExplode(void);
extern SetupFeature(void);
extern void PlayFeature(void);*/
typedef signed long fixed;

//timer.inc
extern void InstallTimeInt();
extern void MyTimeInt();
extern void DeInstallTime();
extern void InstallKeyInt();
extern int GetTime();

//key.inc
extern void MyKeyInt();
extern char ReadArray();
extern void DeInstallKey();

//sysasm.asm
extern void SetFloorCeiling(char *theFloor, char *theCeiling);
extern ShipDrawBufferPtr GetShipDrawBuffer();

//mouse.inc
extern void InitMouse();
extern void ShowMouse();
extern void MouseCtrl(int xMin, int yMin, int xMax, int yMax);
extern long MousePos();
extern int MouseButton();
extern void DrawMouse();
extern char *GetMouseBuffer();

//timer.inc
extern void DrawAllEnemies();

//sysasm.asm routines

//midi
extern int PlaySequence(int theSequence);
extern void SequeSequence (int theSequence, int theActivCode);
extern int RegisterXMidi (char *thePtr, int theLength);
extern void MidiStop();
extern void ResumePlaying();
char* LoadMIDI(char *filename);
void InitMIDI();


//sound
extern void DigPlay(SoundStruc far *theSoundStruc);
void LoadSound(char filename[], SoundStruc *tempSound);

/*extern SetupMarvin(void);
extern void PlayMarvin(void);
extern SetupGuns(void);
extern void PlayGuns(void);
extern SetupExplode(void);
extern void PlayExplode(void);
extern SetupFeature(void);
extern void PlayFeature(void);*/


//general
extern int SequenceStatus();
extern void RegisterXMidiFile(char *thePtr);
extern int RelativeVolume();
extern int SetRelativeVolume();

#endif
