//ship.c

#include <string.h>
#include <memory.h>
#include <stdio.h>
#include <malloc.h>
#include "utils.h"
#include "ship.h"

const float zmax = 2000;

Ship *FReadShip(FILE *theFile) {
	float tempx, tempy, tempz;
	float tempvx, tempvy, tempvz;
	Ship *tempShip;

	if (!feof(theFile)) {
		if ((tempShip = malloc(sizeof(*tempShip)))==NULL)
			FatalError("out of memory!");
		fscanf(theFile, "%g,%g,%g,%g,%g,%g,%u,%u,%u,%u,%u,%u",
				&tempx, &tempy, &tempz, &tempvx, &tempvy, &tempvz,
				&(tempShip->program), &(tempShip->hits), &(tempShip->points),
				&(tempShip->pictureA), &(tempShip->pictureB), &(tempShip->creationTime));
		tempShip->x = Float2Fixed(tempx);
		tempShip->y = Float2Fixed(tempy);
		tempShip->z = Float2Fixed(tempz);
		tempShip->vx = Float2Fixed(tempvx);
		tempShip->vy = Float2Fixed(tempvy);
		tempShip->vz = Float2Fixed(tempvz);
		
		}
	else
		tempShip = NULL;

	return tempShip;
	}

void UpdateShips() {
	int index = 0;
	Ship *tempShip;
	ShipDrawData tempEntry;
	float factor;

	while (theDrawBuffer->data[index].theShip && (index < 32)) {
		tempShip = theDrawBuffer->data[index].theShip;
		tempShip->x += tempShip->vx;
		tempShip->y += tempShip->vy;
		tempShip->z += tempShip->vz;

		if ((float)(tempShip->z) <= zmax) {
			factor = (zmax - (float)tempShip->z)/zmax;

			theDrawBuffer->data[index].x = ((long)160 << 8) + (long)((float)(tempShip->x - ((long)16<<8)) * factor);
			theDrawBuffer->data[index].y = ((long)100 << 8) + (long)((float)(tempShip->y - ((long)16<<8)) * factor);
			theDrawBuffer->data[index].z = tempShip->z;
			theDrawBuffer->data[index].pictureA = tempShip->pictureA;
			theDrawBuffer->data[index].pictureB = tempShip->pictureB;

			switch(tempShip->program) {
				//entry for U turn
				case 0:
					if ((GetTime() - tempShip->creationTime) > 90) {
						tempShip->creationTime = GetTime();
						tempShip->vx = (tempShip->vz)<<6;
						tempShip->pictureA = 4;
						tempShip->pictureB = 5;
						tempShip->program = 1;
						}
					break;
				case 1:
					if ((GetTime() - tempShip->creationTime) > 90) {
						tempShip->creationTime=GetTime();
						tempShip->vz = 0;
						tempShip->pictureA = 6;
						tempShip->pictureB = 7;
						tempShip->program=2;
						}
					break;
				case 2:
					if ((GetTime() - tempShip->creationTime) > 90) {
						tempShip->creationTime=GetTime();
						tempShip->vz = (-tempShip->vx)>>6;
						tempShip->pictureA = 14;
						tempShip->pictureB = 14;
						tempShip->program=3;
						}
					break;
				case 3:
					if ((GetTime() - tempShip->creationTime) > 90) {
						tempShip->creationTime=GetTime();
						tempShip->vx = 0;
						tempShip->pictureA = 10;
						tempShip->pictureB = 11;
						tempShip->program=4;
						}
					break;
				case 4:
					if ((tempShip->z) <= 1)
						DestroyShip(index);
					break;
				case 5:	// straight -> break left
					if ((GetTime() - tempShip->creationTime) > 90) {
						tempShip->creationTime = GetTime();
						tempShip->vx = (tempShip->vz) << 6;
						tempShip->vy = (-tempShip->vz) << 4;
						tempShip->pictureA = 4;
						tempShip->pictureB = 5;
						tempShip->program = 6;
						}
					break;
				case 6:
					if ((tempShip->y) < -100*256)
						DestroyShip(index);
					break;
				case 7:
					if ((GetTime() - tempShip->creationTime) > 90) {
						tempShip->creationTime = GetTime();
						tempShip->vx = (-tempShip->vz) << 6;
						tempShip->vy = (-tempShip->vz) << 4;
						tempShip->pictureA = 2;
						tempShip->pictureB = 3;
						tempShip->program = 6;
						}
					break;
				case 9:
					DestroyShip(index);
					break;
				default: break;
				}
			}
		else {
			DestroyShip(index);
			}
		index++;
		}	
	SortShips();
	}

void DestroyShip(int index) {
	if (theDrawBuffer->data[index].valid) {
		theDrawBuffer->data[index].valid = 0;
		free(theDrawBuffer->data[index].theShip);

		if (index<31) {
			while (index<31) {
				memcpy(&(theDrawBuffer->data[index]), &(theDrawBuffer->data[index+1]), 32);
				index++;
				}
			theDrawBuffer->data[31].valid=0;
			}
		}
	}
/*
void
EnemySort(unsigned int enemies) {
	Ship *tmp;
	int i, j;
 
	for (i = 1; i<enemies; i++) {
	tmp = ShipDrawBuffer[i].theShip;
	for ( j = i; j > 0; j-- ) {			
		if (tmp->z < ShipDrawBuffer[j-i].theShip->z) {
			memcpy(&ShipDrawBuffer[j], &ShipDrawBuffer[j-1], 32);
//			ShipDrawBuffer[j] = ShipDrawBuffer[j-1];
	    	}
        else	
	    	{
                break;
		    }
        }
	[j] = tmp;
    }
}
*/

void SortShips(unsigned int enemies) {
	}

int AddShipToDrawBuffer(Ship *theShip) {
	int index;
	
	index=32;
	while (index>0 && (theDrawBuffer->data[index-1].valid==0))
		index--;

	if (index==32)
		return 0;
	else {
		while (index>0 && (theDrawBuffer->data[index-1].z < theShip->z)) {
			memcpy(&theDrawBuffer->data[index-1], &theDrawBuffer->data[index], 32);
			index--;
			}

		theDrawBuffer->data[index].valid = 1;
		theDrawBuffer->data[index].x = theShip->x;
		theDrawBuffer->data[index].y = theShip->y;
		theDrawBuffer->data[index].z = theShip->z;
		theDrawBuffer->data[index].pictureA = theShip->pictureA;
		theDrawBuffer->data[index].pictureB = theShip->pictureB;
		theDrawBuffer->data[index].theShip = theShip;
		
		return 1;
		}
	}
