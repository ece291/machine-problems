typedef long fixed;
typedef unsigned int mySegment;

#ifndef __UTILS__
#define __UTILS__


#include "mysystem.h"


//externs for routines in utils.asm
extern void MyDelay(unsigned long uSecs);
extern mySegment SegmentOf(void *segptr);
extern int MyRandom();

//utils.c routines
fixed Float2Fixed(float x);
float Fixed2Float(fixed x);
void FatalError(const char *theMessage);
char CheckKey();
char *Seg2Ptr(mySegment theSeg);

#endif
