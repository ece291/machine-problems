//ship.h
#ifndef __SHIP__
#define __SHIP__

#include <stdio.h>
#include "utils.h"

typedef struct Ship_t {
	fixed x, y, z, vx, vy, vz;
	int program;
	int hits;
	int points;
	char pictureA, pictureB;
	int creationTime;
	} Ship;

typedef struct ShipDrawData_t {
	char valid;			// +0
	Ship *theShip;		// +2
	fixed x;			// +6
	fixed y;			// +10
	fixed z;			// +14
	char pictureA;		// +18
	char pictureB;		// +19
	char filler[12];	// +20
	// total size = 32
	} ShipDrawData;
								
typedef struct ShipDrawBuffer_t {
	ShipDrawData data[32];
	} *ShipDrawBufferPtr;
	// total size = 1k

ShipDrawBufferPtr theDrawBuffer;

//ship.c
Ship *FReadShip(FILE *theFile);
void UpdateShips();
void DestroyShip(int dataBufferNum);
void SortShips();
int AddShipToDrawBuffer(Ship *theShip);

#endif
