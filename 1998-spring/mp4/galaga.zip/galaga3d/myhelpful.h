#ifndef myhelpful_h
#define myhelpful_h

typedef enum MoveCheck_t { Valid, InValid};

#endif