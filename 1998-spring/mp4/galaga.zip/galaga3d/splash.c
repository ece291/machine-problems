void Splash() {
    Palette nullPalette, thePalette;
	int index,temp;
    float tempFloat;
    RGBColor nullColor = {0,0,0};
	GetPalette(&thePalette);

	for (temp=0; temp<10; temp++){
        for(index=0; index<256; index++) {
            nullPalette.theColors[index].r = 255;
            nullPalette.theColors[index].g = 255;
            nullPalette.theColors[index].b = 255;
            }
		SetPalette(&nullPalette);
		MyDelay(500);
        SetPalette(&thePalette);
	}
}
