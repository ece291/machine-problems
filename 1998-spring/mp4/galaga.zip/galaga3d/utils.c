//utils.c for Galaga 3D

#include <stdlib.h>
#include <errno.h>
#include <stdio.h>
#include "mysystem.h"
#include "graphics.h"
#include "utils.h"

fixed Float2Fixed(float x) {
    return (x*256.0);
	}

float Fixed2Float(fixed x) {
	return (x/256.0);
	}

void FatalError(const char *theMessage) {
	SetModeText();
	fcloseall();
	printf("\nFatal error: \n"); perror(theMessage);
	exit(-1);
	}

char *Seg2Ptr(mySegment theSeg) {
	return (char *)((long)theSeg<<16);
	}