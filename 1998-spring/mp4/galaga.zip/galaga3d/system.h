#ifndef __GRAPHICS__
#define __GRAPHICS__

#include "utils.h"

//header forsystemasm.asm
extern void InstallTimeInt();
extern void MyTimeInt();
extern void DeInstallTime();
extern void InstallKeyInt();
extern void MyKeyInt();
extern char ReadArray();
extern void DeInstallKey();
extern void InitMouse();
extern void ShowMouse();
extern void MouseCtrl(int xMin, int xMax, int yMin, int yMax);
extern void MousePos();
extern void MouseButton();
extern void DrawMouse();
extern void SetMouse(char *theBitmap);
extern void SetFloorCeiling(char *theBitmap, char *theBitmap1);

//midi
extern int PlaySequence(int theSequence);
extern void SequeSequence (int theSequence, int theActivCode);
extern int RegisterXMidi (void *thePtr, long theLength);
extern void MidiStop();
extern void ResumePlaying();
extern int SequenceStatus();
extern void RegisterXMidiFile(void *thePtr);
extern int RelativeVolume();
extern int SetRelativeVolume();

#endif
