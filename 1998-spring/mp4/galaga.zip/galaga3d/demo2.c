#include <stdio.h>
#include <malloc.h>
#include "graphics.h"
#include "system.h"
#include "utils.h"
#include "math.h"

const segment ScreenSeg = 0xA000;
const RGBColor nullColor = {0,0,0};
const RGBColor whiteColor = {63, 63, 63};

void FlyingLetters() {
	Palette nullPalette;
	char *letterG, *letterA, *letterL;
	char *shapes[6];
	int posX[6] = {85, 109, 137, 156, 182, 206};
	int	factor[6] = {0, -40, -80, -120, -160, -180};
	int temp;
	segment ScratchSeg = GetScratchSeg(), ScratchSegB = GetScratchSegB();
 
	if (!LoadPCX("f:\\galaga\\data\\g.pcx", &letterG, &nullPalette))
		FatalError("Could not load g");
	LoadPCX("f:\\galaga\\data\\a.pcx", &letterA, &nullPalette);
	LoadPCX("f:\\galaga\\data\\l.pcx", &letterL, &nullPalette);

	shapes[0] = letterG; shapes[1] = letterA; shapes[2] = letterL;
	shapes[3] = letterA; shapes[4] = letterG; shapes[5] = letterA;


	ScreenToScreen(ScratchSegB, ScreenSeg);
	SetDrawDest(ScratchSeg);
	while (factor[5] < 256) {
		ScreenToScreen(ScratchSeg, ScratchSegB);
		for(temp=0; temp<6; temp++) {
			factor[temp]+= 1;
			if (factor[temp] > 256)
				factor[temp] = 256;
			if (factor[temp]>0)
				TSDrawBitmap(shapes[temp], posX[temp], 82, factor[temp], factor[temp]);			}
		ScreenToScreen(ScreenSeg, ScratchSeg);
		MyDelay(5000);
		}
	
	free(letterG); free(letterA); free(letterL);
	}

void Explosion() {
	char *burst;
	Palette nullPalette;
	segment ScratchSeg = GetScratchSeg(), ScratchSegB = GetScratchSegB();
	int tempInt, currDot;
	int	vx[400], vy[400], x[400], y[400];

	LoadPCX("f:\\galaga\\data\\burst.pcx", &burst, &nullPalette);

	ScreenToScreen(ScratchSegB, ScreenSeg);
	SetDrawDest(ScratchSeg);

	for(currDot=0; currDot<400; currDot++) {
		x[currDot] = (rand() % 580) + 340;
		y[currDot] = (rand() % 252) + 328;
		vx[currDot] = (rand() % 18) - 9;
		if (!vx[currDot])
			vx[currDot]++;
		vy[currDot] = (rand() % 18) - 9;
		if (!vy[currDot])
			vy[currDot]++;

		
		}

	for(tempInt=0; tempInt<1000; tempInt++) {
		ScreenToScreen(ScratchSeg, ScratchSegB);
		for(currDot=1; currDot<399; currDot++) {
			x[currDot] += vx[currDot];
			y[currDot] += vy[currDot];
			if ((y[currDot] > 0) && (y[currDot]<784) && (x[currDot]>0) && (x[currDot]<1264))
				TDrawBitmap(burst, (x[currDot]>>2), (y[currDot]>>2));
			}
		ScreenToScreen(ScreenSeg, ScratchSeg);
		MyDelay(1500);
		}
	free(burst);

	}

void main() {
	segment ScratchSeg = GetScratchSeg(), ScratchSegB = GetScratchSegB();
	Palette thePalette, nullPalette, groundPalette;
	char *theBackground, *theMenu, *theMouseCursor, *theTitle2, *theClouds, *theGround;
	char *theShips, *theStatusBar;
	char quitFlag=0;
	col colorIndex;
	void *tempSeg = (void *)((long)GetScratchSeg()<<16);
	void *tempSegB = (void *)((long)GetScratchSegB()<<16);
	fixed factor, factorV;
	int tempInt;

	if (!LoadPCX("f:\\galaga\\data\\image2.pcx", &theBackground, &thePalette))
		FatalError("Could not load background!");
	if (!LoadPCX("f:\\galaga\\data\\menu.pcx", &theMenu, &nullPalette))
		FatalError("Could not load menu1");
	if (!LoadPCX("f:\\galaga\\data\\3d.pcx", &theTitle2, &nullPalette))
		FatalError("Could not load title2");
/*	if (!LoadPCX("f:\\galaga\\data\\shipall.pcx", &theShips, &nullPalette));
		FatalError("Could not load ship bitmaps"); */
	if (!LoadPCX("f:\\galaga\\data\\cursor.pcx", &theMouseCursor, &nullPalette))
		FatalError("Could not load cursor");
	if (!LoadPCX("f:\\galaga\\data\\statbar.pcx", &theStatusBar, &nullPalette))
		FatalError("Could not load status bar");
    
	if (!LoadPCX("data\\floor15.pcx", &theGround, &groundPalette))
		exit(-1);
	if (!LoadPCX("data\\flfcloud.pcx", &theClouds, &nullPalette))
		exit(-1);
	
	
	for (colorIndex=255; colorIndex>0; colorIndex--)
		nullPalette.theColors[colorIndex] = nullColor;

	SetMode13();
	SetPalette(&nullPalette);

	FadeIn(&thePalette, 5000);

	SetDrawDest(ScratchSeg);
	for(factor=1; factor<256; factor+=2) {
		FillScreen(0);
		TSDrawBitmap(theBackground, 255-factor, 255-factor, 256+(255-factor), 256+(255-factor));
		TSDrawBitmap(theMenu, 79-(255-factor), 49-(255-factor), factor, factor);
		ScreenToScreen(ScreenSeg, ScratchSeg);
		MyDelay(15000);
		}

/*	FlyingLetters();
	SetDrawDest(ScreenSeg);
	for(tempInt=0; tempInt<40; tempInt++) {
		AddDrawBitmap(theTitle2, 165, 100);
		MyDelay(15000);
		}
	Explosion(); */
	getch(); 
	FadeOut(&thePalette, 5000);

	free(theBackground);
	free(theMenu);

	SetFloorCeiling(theGround, theClouds);
	InitMouse();
	SetMouse(theMouseCursor);
	MouseCtrl(0, 305, 0, 165);
	InitFloor();
	
	for(colorIndex=255; colorIndex>0; colorIndex--)
		nullPalette.theColors[colorIndex] = whiteColor;

	FillScreen(0);
	SetDrawDest(ScreenSeg);
	DrawBitmap(theStatusBar, 0, 180, 256, 256);
	
	SetDrawDest(ScratchSeg);
	InstallTimeInt();         	

	FadeIn(&groundPalette, 100000);

	ShowMouse();

	do {
		tempInt = MouseButton();
		quitFlag = tempInt & 1;
		if (tempInt & 2) {
			SetPalette(&nullPalette);
			MyDelay(25000);
			SetPalette(&groundPalette);
			}
		} while (!quitFlag);

	FadeOut(&groundPalette, 100000);
	DeInstallTime();

	SetModeText();

	free(theGround);
	free(theClouds);
	free(theMouseCursor);

    }